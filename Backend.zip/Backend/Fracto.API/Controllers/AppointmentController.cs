using Fracto.Core.DTOs;
using Fracto.Core.Entities;
using Fracto.Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Fracto.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class AppointmentController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AppointmentController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<AppointmentSearchResultDto>> GetAppointments([FromQuery] AppointmentSearchDto searchDto)
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var isAdmin = User.IsInRole("Admin");
                var isDoctor = User.IsInRole("Doctor");

                var query = _context.Appointments
                    .Include(a => a.Patient)
                    .Include(a => a.Doctor)
                    .Include(a => a.Doctor.Specialization)
                    .Include(a => a.TimeSlot)
                    .AsQueryable();

                // Apply role-based filtering
                if (!isAdmin)
                {
                    if (isDoctor)
                    {
                        query = query.Where(a => a.DoctorId == currentUserId);
                    }
                    else
                    {
                        query = query.Where(a => a.PatientId == currentUserId);
                    }
                }

                // Apply search filters
                if (!string.IsNullOrEmpty(searchDto.PatientId))
                {
                    query = query.Where(a => a.PatientId == searchDto.PatientId);
                }

                if (!string.IsNullOrEmpty(searchDto.DoctorId))
                {
                    query = query.Where(a => a.DoctorId == searchDto.DoctorId);
                }

                if (searchDto.Status.HasValue)
                {
                    query = query.Where(a => a.Status == searchDto.Status.Value);
                }

                if (searchDto.FromDate.HasValue)
                {
                    query = query.Where(a => a.AppointmentDate >= searchDto.FromDate.Value);
                }

                if (searchDto.ToDate.HasValue)
                {
                    query = query.Where(a => a.AppointmentDate <= searchDto.ToDate.Value);
                }

                // Calculate total count before pagination
                var totalCount = await query.CountAsync();

                // Apply pagination
                var appointments = await query
                    .OrderByDescending(a => a.AppointmentDate)
                    .ThenBy(a => a.AppointmentTime)
                    .Skip((searchDto.Page - 1) * searchDto.PageSize)
                    .Take(searchDto.PageSize)
                    .Select(a => new AppointmentDto
                    {
                        Id = a.Id,
                        PatientId = a.PatientId,
                        PatientName = a.Patient != null ? a.Patient.FullName : "Unknown Patient",
                        DoctorId = a.DoctorId,
                        DoctorName = a.Doctor != null ? a.Doctor.FullName : "Unknown Doctor",
                        SpecializationName = a.Doctor != null && a.Doctor.Specialization != null ? a.Doctor.Specialization.Name : "Unknown Specialization",
                        AppointmentDate = a.AppointmentDate,
                        AppointmentTime = a.AppointmentTime,
                        Symptoms = a.Symptoms,
                        Notes = a.Notes,
                        Status = a.Status,
                        CreatedAt = a.CreatedAt,
                        UpdatedAt = a.UpdatedAt,
                        CancelledAt = a.CancelledAt,
                        CancellationReason = a.CancellationReason,
                        ConsultationFee = a.Doctor != null ? a.Doctor.ConsultationFee : 0
                    })
                    .ToListAsync();

                var totalPages = (int)Math.Ceiling((double)totalCount / searchDto.PageSize);

                return Ok(new AppointmentSearchResultDto
                {
                    Appointments = appointments,
                    TotalCount = totalCount,
                    Page = searchDto.Page,
                    PageSize = searchDto.PageSize,
                    TotalPages = totalPages
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching appointments", error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<AppointmentDto>> GetAppointment(int id)
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var isAdmin = User.IsInRole("Admin");

                var appointment = await _context.Appointments
                    .Include(a => a.Patient)
                    .Include(a => a.Doctor)
                    .Include(a => a.Doctor.Specialization)
                    .Include(a => a.TimeSlot)
                    .FirstOrDefaultAsync(a => a.Id == id);

                if (appointment == null)
                {
                    return NotFound();
                }

                // Check if user has access to this appointment
                if (!isAdmin && appointment.PatientId != currentUserId && appointment.DoctorId != currentUserId)
                {
                    return Forbid();
                }

                var appointmentDto = new AppointmentDto
                {
                    Id = appointment.Id,
                    PatientId = appointment.PatientId,
                    PatientName = appointment.Patient?.FullName ?? "Unknown Patient",
                    DoctorId = appointment.DoctorId,
                    DoctorName = appointment.Doctor?.FullName ?? "Unknown Doctor",
                    SpecializationName = appointment.Doctor?.Specialization?.Name ?? "Unknown Specialization",
                    AppointmentDate = appointment.AppointmentDate,
                    AppointmentTime = appointment.AppointmentTime,
                    Symptoms = appointment.Symptoms,
                    Notes = appointment.Notes,
                    Status = appointment.Status,
                    CreatedAt = appointment.CreatedAt,
                    UpdatedAt = appointment.UpdatedAt,
                    CancelledAt = appointment.CancelledAt,
                    CancellationReason = appointment.CancellationReason,
                    ConsultationFee = appointment.Doctor?.ConsultationFee ?? 0
                };

                return Ok(appointmentDto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching appointment", error = ex.Message });
            }
        }

        [HttpPost]
        public async Task<ActionResult<AppointmentDto>> CreateAppointment([FromBody] CreateAppointmentDto createAppointmentDto)
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                // Validate time slot availability
                var timeSlot = await _context.TimeSlots
                    .Include(ts => ts.Doctor)
                    .FirstOrDefaultAsync(ts => ts.Id == createAppointmentDto.TimeSlotId);

                if (timeSlot == null)
                {
                    return BadRequest("Invalid time slot");
                }

                if (timeSlot.IsBooked || !timeSlot.IsAvailable)
                {
                    return BadRequest("Time slot is not available");
                }

                if (timeSlot.DoctorId != createAppointmentDto.DoctorId)
                {
                    return BadRequest("Time slot does not belong to the specified doctor");
                }

                // Check if appointment date is in the future
                if (createAppointmentDto.AppointmentDate.Date <= DateTime.Today)
                {
                    return BadRequest("Appointment date must be in the future");
                }

                var appointment = new Appointment
                {
                    PatientId = currentUserId,
                    DoctorId = createAppointmentDto.DoctorId,
                    TimeSlotId = createAppointmentDto.TimeSlotId,
                    AppointmentDate = createAppointmentDto.AppointmentDate,
                    AppointmentTime = createAppointmentDto.AppointmentTime,
                    Symptoms = createAppointmentDto.Symptoms,
                    Notes = createAppointmentDto.Notes,
                    Status = AppointmentStatus.Pending,
                    CreatedAt = DateTime.UtcNow
                };

                // Mark time slot as booked
                timeSlot.IsBooked = true;

                _context.Appointments.Add(appointment);
                await _context.SaveChangesAsync();

                // Fetch the created appointment with related data
                var createdAppointment = await _context.Appointments
                    .Include(a => a.Patient)
                    .Include(a => a.Doctor)
                    .Include(a => a.Doctor.Specialization)
                    .FirstOrDefaultAsync(a => a.Id == appointment.Id);

                var appointmentDto = new AppointmentDto
                {
                    Id = createdAppointment.Id,
                    PatientId = createdAppointment.PatientId,
                    PatientName = createdAppointment.Patient?.FullName ?? "Unknown Patient",
                    DoctorId = createdAppointment.DoctorId,
                    DoctorName = createdAppointment.Doctor?.FullName ?? "Unknown Doctor",
                    SpecializationName = createdAppointment.Doctor?.Specialization?.Name ?? "Unknown Specialization",
                    AppointmentDate = createdAppointment.AppointmentDate,
                    AppointmentTime = createdAppointment.AppointmentTime,
                    Symptoms = createdAppointment.Symptoms,
                    Notes = createdAppointment.Notes,
                    Status = createdAppointment.Status,
                    CreatedAt = createdAppointment.CreatedAt,
                    UpdatedAt = createdAppointment.UpdatedAt,
                    CancelledAt = createdAppointment.CancelledAt,
                    CancellationReason = createdAppointment.CancellationReason,
                    ConsultationFee = createdAppointment.Doctor?.ConsultationFee ?? 0
                };

                return CreatedAtAction(nameof(GetAppointment), new { id = appointment.Id }, appointmentDto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while creating appointment", error = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateAppointment(int id, [FromBody] UpdateAppointmentDto updateAppointmentDto)
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var isAdmin = User.IsInRole("Admin");

                var appointment = await _context.Appointments
                    .Include(a => a.TimeSlot)
                    .FirstOrDefaultAsync(a => a.Id == id);

                if (appointment == null)
                {
                    return NotFound();
                }

                // Check if user has access to update this appointment
                if (!isAdmin && appointment.PatientId != currentUserId && appointment.DoctorId != currentUserId)
                {
                    return Forbid();
                }

                // Only allow updates if appointment is not completed or cancelled
                if (appointment.Status == AppointmentStatus.Completed || appointment.Status == AppointmentStatus.Cancelled)
                {
                    return BadRequest("Cannot update completed or cancelled appointments");
                }

                if (updateAppointmentDto.Symptoms != null)
                    appointment.Symptoms = updateAppointmentDto.Symptoms;
                if (updateAppointmentDto.Notes != null)
                    appointment.Notes = updateAppointmentDto.Notes;
                if (updateAppointmentDto.Status.HasValue)
                {
                    appointment.Status = updateAppointmentDto.Status.Value;
                    
                    // If appointment is cancelled, free up the time slot
                    if (updateAppointmentDto.Status.Value == AppointmentStatus.Cancelled)
                    {
                        appointment.CancelledAt = DateTime.UtcNow;
                        if (appointment.TimeSlot != null)
                        {
                            appointment.TimeSlot.IsBooked = false;
                        }
                    }
                }
                if (updateAppointmentDto.CancellationReason != null)
                    appointment.CancellationReason = updateAppointmentDto.CancellationReason;

                appointment.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating appointment", error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> CancelAppointment(int id, [FromBody] string? cancellationReason = null)
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var isAdmin = User.IsInRole("Admin");

                var appointment = await _context.Appointments
                    .Include(a => a.TimeSlot)
                    .FirstOrDefaultAsync(a => a.Id == id);

                if (appointment == null)
                {
                    return NotFound();
                }

                // Check if user has access to cancel this appointment
                if (!isAdmin && appointment.PatientId != currentUserId && appointment.DoctorId != currentUserId)
                {
                    return Forbid();
                }

                // Only allow cancellation if appointment is not completed
                if (appointment.Status == AppointmentStatus.Completed)
                {
                    return BadRequest("Cannot cancel completed appointments");
                }

                appointment.Status = AppointmentStatus.Cancelled;
                appointment.CancelledAt = DateTime.UtcNow;
                appointment.CancellationReason = cancellationReason;
                appointment.UpdatedAt = DateTime.UtcNow;

                // Free up the time slot
                if (appointment.TimeSlot != null)
                {
                    appointment.TimeSlot.IsBooked = false;
                }

                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while cancelling appointment", error = ex.Message });
            }
        }

        [HttpPost("{id}/confirm")]
        [Authorize(Roles = "Admin,Doctor")]
        public async Task<ActionResult> ConfirmAppointment(int id)
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var isAdmin = User.IsInRole("Admin");

                var appointment = await _context.Appointments.FindAsync(id);
                if (appointment == null)
                {
                    return NotFound();
                }

                // Check if the current user is the doctor or an admin
                if (!isAdmin && appointment.DoctorId != currentUserId)
                {
                    return Forbid();
                }

                if (appointment.Status != AppointmentStatus.Pending)
                {
                    return BadRequest("Only pending appointments can be confirmed");
                }

                appointment.Status = AppointmentStatus.Confirmed;
                appointment.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while confirming appointment", error = ex.Message });
            }
        }

        [HttpPost("{id}/complete")]
        [Authorize(Roles = "Admin,Doctor")]
        public async Task<ActionResult> CompleteAppointment(int id)
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var isAdmin = User.IsInRole("Admin");

                var appointment = await _context.Appointments.FindAsync(id);
                if (appointment == null)
                {
                    return NotFound();
                }

                // Check if the current user is the doctor or an admin
                if (!isAdmin && appointment.DoctorId != currentUserId)
                {
                    return Forbid();
                }

                if (appointment.Status != AppointmentStatus.Confirmed)
                {
                    return BadRequest("Only confirmed appointments can be completed");
                }

                appointment.Status = AppointmentStatus.Completed;
                appointment.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while completing appointment", error = ex.Message });
            }
        }
    }
}
