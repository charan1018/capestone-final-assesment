using Fracto.API.Services;
using Fracto.Core.DTOs;
using Fracto.Core.Entities;
using Fracto.Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Fracto.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IJwtService _jwtService;
        private readonly ApplicationDbContext _context;

        public AuthController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            RoleManager<IdentityRole> roleManager,
            IJwtService jwtService,
            ApplicationDbContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _jwtService = jwtService;
            _context = context;
        }

        [HttpPost("login")]
        public async Task<ActionResult<AuthResponseDto>> Login([FromBody] LoginDto loginDto)
        {
            try
            {
                var user = await _userManager.FindByEmailAsync(loginDto.Email);
                if (user == null)
                {
                    return BadRequest(new AuthResponseDto
                    {
                        IsSuccess = false,
                        Message = "Invalid email or password"
                    });
                }

                var result = await _signInManager.CheckPasswordSignInAsync(user, loginDto.Password, false);
                if (!result.Succeeded)
                {
                    return BadRequest(new AuthResponseDto
                    {
                        IsSuccess = false,
                        Message = "Invalid email or password"
                    });
                }

                var roles = await _userManager.GetRolesAsync(user);
                var token = _jwtService.GenerateToken(user, roles);

                var userDto = new UserDto
                {
                    Id = user.Id,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email ?? string.Empty,
                    PhoneNumber = user.PhoneNumber,
                    Address = user.Address,
                    City = user.City,
                    DateOfBirth = user.DateOfBirth,
                    ProfileImagePath = user.ProfileImagePath,
                    Roles = roles.ToList()
                };

                return Ok(new AuthResponseDto
                {
                    IsSuccess = true,
                    Message = "Login successful",
                    Token = token,
                    ExpiresAt = DateTime.UtcNow.AddHours(24),
                    User = userDto
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new AuthResponseDto
                {
                    IsSuccess = false,
                    Message = "An error occurred during login",
                    Errors = new List<string> { ex.Message }
                });
            }
        }

        [HttpPost("register")]
        public async Task<ActionResult<AuthResponseDto>> Register([FromBody] RegisterDto registerDto)
        {
            try
            {
                if (await _userManager.FindByEmailAsync(registerDto.Email) != null)
                {
                    return BadRequest(new AuthResponseDto
                    {
                        IsSuccess = false,
                        Message = "Email already exists"
                    });
                }

                var user = new ApplicationUser
                {
                    UserName = registerDto.Email,
                    Email = registerDto.Email,
                    FirstName = registerDto.FirstName,
                    LastName = registerDto.LastName,
                    Address = registerDto.Address,
                    City = registerDto.City,
                    PhoneNumber = registerDto.PhoneNumber,
                    DateOfBirth = registerDto.DateOfBirth,
                    CreatedAt = DateTime.UtcNow
                };

                var result = await _userManager.CreateAsync(user, registerDto.Password);
                if (!result.Succeeded)
                {
                    return BadRequest(new AuthResponseDto
                    {
                        IsSuccess = false,
                        Message = "Registration failed",
                        Errors = result.Errors.Select(e => e.Description).ToList()
                    });
                }

                // Assign default role
                await _userManager.AddToRoleAsync(user, "User");

                var roles = await _userManager.GetRolesAsync(user);
                var token = _jwtService.GenerateToken(user, roles);

                var userDto = new UserDto
                {
                    Id = user.Id,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email ?? string.Empty,
                    PhoneNumber = user.PhoneNumber,
                    Address = user.Address,
                    City = user.City,
                    DateOfBirth = user.DateOfBirth,
                    ProfileImagePath = user.ProfileImagePath,
                    Roles = roles.ToList()
                };

                return Ok(new AuthResponseDto
                {
                    IsSuccess = true,
                    Message = "Registration successful",
                    Token = token,
                    ExpiresAt = DateTime.UtcNow.AddHours(24),
                    User = userDto
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new AuthResponseDto
                {
                    IsSuccess = false,
                    Message = "An error occurred during registration",
                    Errors = new List<string> { ex.Message }
                });
            }
        }

        [HttpPost("register-doctor")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<AuthResponseDto>> RegisterDoctor([FromBody] DoctorRegisterDto doctorDto)
        {
            try
            {
                if (await _userManager.FindByEmailAsync(doctorDto.Email) != null)
                {
                    return BadRequest(new AuthResponseDto
                    {
                        IsSuccess = false,
                        Message = "Email already exists"
                    });
                }

                var doctor = new Doctor
                {
                    UserName = doctorDto.Email,
                    Email = doctorDto.Email,
                    FirstName = doctorDto.FirstName,
                    LastName = doctorDto.LastName,
                    Address = doctorDto.Address,
                    City = doctorDto.City,
                    PhoneNumber = doctorDto.PhoneNumber,
                    DateOfBirth = doctorDto.DateOfBirth,
                    LicenseNumber = doctorDto.LicenseNumber,
                    Biography = doctorDto.Biography,
                    Hospital = doctorDto.Hospital,
                    Clinic = doctorDto.Clinic,
                    ConsultationFee = doctorDto.ConsultationFee,
                    ExperienceYears = doctorDto.ExperienceYears,
                    StartTime = doctorDto.StartTime,
                    EndTime = doctorDto.EndTime,
                    SpecializationId = doctorDto.SpecializationId,
                    CreatedAt = DateTime.UtcNow
                };

                var result = await _userManager.CreateAsync(doctor, doctorDto.Password);
                if (!result.Succeeded)
                {
                    return BadRequest(new AuthResponseDto
                    {
                        IsSuccess = false,
                        Message = "Doctor registration failed",
                        Errors = result.Errors.Select(e => e.Description).ToList()
                    });
                }

                // Assign Doctor role
                await _userManager.AddToRoleAsync(doctor, "Doctor");

                var roles = await _userManager.GetRolesAsync(doctor);
                var token = _jwtService.GenerateToken(doctor, roles);

                var userDto = new UserDto
                {
                    Id = doctor.Id,
                    FirstName = doctor.FirstName,
                    LastName = doctor.LastName,
                    Email = doctor.Email ?? string.Empty,
                    PhoneNumber = doctor.PhoneNumber,
                    Address = doctor.Address,
                    City = doctor.City,
                    DateOfBirth = doctor.DateOfBirth,
                    ProfileImagePath = doctor.ProfileImagePath,
                    Roles = roles.ToList()
                };

                return Ok(new AuthResponseDto
                {
                    IsSuccess = true,
                    Message = "Doctor registration successful",
                    Token = token,
                    ExpiresAt = DateTime.UtcNow.AddHours(24),
                    User = userDto
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new AuthResponseDto
                {
                    IsSuccess = false,
                    Message = "An error occurred during doctor registration",
                    Errors = new List<string> { ex.Message }
                });
            }
        }

        [HttpGet("profile")]
        [Authorize]
        public async Task<ActionResult<UserDto>> GetProfile()
        {
            try
            {
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(userId))
                {
                    return Unauthorized();
                }

                var user = await _userManager.FindByIdAsync(userId);
                if (user == null)
                {
                    return NotFound();
                }

                var roles = await _userManager.GetRolesAsync(user);

                var userDto = new UserDto
                {
                    Id = user.Id,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email ?? string.Empty,
                    PhoneNumber = user.PhoneNumber,
                    Address = user.Address,
                    City = user.City,
                    DateOfBirth = user.DateOfBirth,
                    ProfileImagePath = user.ProfileImagePath,
                    Roles = roles.ToList()
                };

                return Ok(userDto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching profile", error = ex.Message });
            }
        }

        [HttpPost("logout")]
        [Authorize]
        public async Task<ActionResult> Logout()
        {
            try
            {
                await _signInManager.SignOutAsync();
                return Ok(new { message = "Logout successful" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred during logout", error = ex.Message });
            }
        }
    }
}
