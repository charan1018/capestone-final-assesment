using Fracto.Core.DTOs;
using Fracto.Core.Entities;
using Fracto.Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Fracto.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class RatingController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public RatingController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<RatingDto>>> GetRatings([FromQuery] string? doctorId = null)
        {
            try
            {
                var query = _context.Ratings
                    .Include(r => r.Patient)
                    .Include(r => r.Doctor)
                    .Include(r => r.Appointment)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(doctorId))
                {
                    query = query.Where(r => r.DoctorId == doctorId);
                }

                var ratings = await query
                    .OrderByDescending(r => r.CreatedAt)
                    .Select(r => new RatingDto
                    {
                        Id = r.Id,
                        PatientId = r.PatientId,
                        PatientName = r.Patient != null ? r.Patient.FullName : "Unknown Patient",
                        DoctorId = r.DoctorId,
                        DoctorName = r.Doctor != null ? r.Doctor.FullName : "Unknown Doctor",
                        AppointmentId = r.AppointmentId,
                        RatingValue = r.RatingValue,
                        Review = r.Review,
                        CreatedAt = r.CreatedAt,
                        UpdatedAt = r.UpdatedAt
                    })
                    .ToListAsync();

                return Ok(ratings);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching ratings", error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<RatingDto>> GetRating(int id)
        {
            try
            {
                var rating = await _context.Ratings
                    .Include(r => r.Patient)
                    .Include(r => r.Doctor)
                    .Include(r => r.Appointment)
                    .FirstOrDefaultAsync(r => r.Id == id);

                if (rating == null)
                {
                    return NotFound();
                }

                var ratingDto = new RatingDto
                {
                    Id = rating.Id,
                    PatientId = rating.PatientId,
                    PatientName = rating.Patient?.FullName ?? "Unknown Patient",
                    DoctorId = rating.DoctorId,
                    DoctorName = rating.Doctor?.FullName ?? "Unknown Doctor",
                    AppointmentId = rating.AppointmentId,
                    RatingValue = rating.RatingValue,
                    Review = rating.Review,
                    CreatedAt = rating.CreatedAt,
                    UpdatedAt = rating.UpdatedAt
                };

                return Ok(ratingDto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching rating", error = ex.Message });
            }
        }

        [HttpPost]
        public async Task<ActionResult<RatingDto>> CreateRating([FromBody] CreateRatingDto createRatingDto)
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                // Validate that the appointment exists and belongs to the current user
                var appointment = await _context.Appointments
                    .Include(a => a.Doctor)
                    .FirstOrDefaultAsync(a => a.Id == createRatingDto.AppointmentId);

                if (appointment == null)
                {
                    return BadRequest("Invalid appointment");
                }

                if (appointment.PatientId != currentUserId)
                {
                    return Forbid();
                }

                if (appointment.DoctorId != createRatingDto.DoctorId)
                {
                    return BadRequest("Doctor ID does not match the appointment");
                }

                // Check if appointment is completed (only completed appointments can be rated)
                if (appointment.Status != AppointmentStatus.Completed)
                {
                    return BadRequest("Only completed appointments can be rated");
                }

                // Check if rating already exists for this appointment
                var existingRating = await _context.Ratings
                    .FirstOrDefaultAsync(r => r.AppointmentId == createRatingDto.AppointmentId);

                if (existingRating != null)
                {
                    return BadRequest("Appointment has already been rated");
                }

                var rating = new Rating
                {
                    PatientId = currentUserId,
                    DoctorId = createRatingDto.DoctorId,
                    AppointmentId = createRatingDto.AppointmentId,
                    RatingValue = createRatingDto.RatingValue,
                    Review = createRatingDto.Review,
                    CreatedAt = DateTime.UtcNow
                };

                _context.Ratings.Add(rating);
                await _context.SaveChangesAsync();

                // Fetch the created rating with related data
                var createdRating = await _context.Ratings
                    .Include(r => r.Patient)
                    .Include(r => r.Doctor)
                    .FirstOrDefaultAsync(r => r.Id == rating.Id);

                var ratingDto = new RatingDto
                {
                    Id = createdRating.Id,
                    PatientId = createdRating.PatientId,
                    PatientName = createdRating.Patient?.FullName ?? "Unknown Patient",
                    DoctorId = createdRating.DoctorId,
                    DoctorName = createdRating.Doctor?.FullName ?? "Unknown Doctor",
                    AppointmentId = createdRating.AppointmentId,
                    RatingValue = createdRating.RatingValue,
                    Review = createdRating.Review,
                    CreatedAt = createdRating.CreatedAt,
                    UpdatedAt = createdRating.UpdatedAt
                };

                return CreatedAtAction(nameof(GetRating), new { id = rating.Id }, ratingDto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while creating rating", error = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateRating(int id, [FromBody] UpdateRatingDto updateRatingDto)
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                var rating = await _context.Ratings.FindAsync(id);
                if (rating == null)
                {
                    return NotFound();
                }

                // Only the patient who created the rating can update it
                if (rating.PatientId != currentUserId)
                {
                    return Forbid();
                }

                if (updateRatingDto.RatingValue.HasValue)
                    rating.RatingValue = updateRatingDto.RatingValue.Value;
                if (updateRatingDto.Review != null)
                    rating.Review = updateRatingDto.Review;

                rating.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating rating", error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteRating(int id)
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var isAdmin = User.IsInRole("Admin");

                var rating = await _context.Ratings.FindAsync(id);
                if (rating == null)
                {
                    return NotFound();
                }

                // Only the patient who created the rating or an admin can delete it
                if (!isAdmin && rating.PatientId != currentUserId)
                {
                    return Forbid();
                }

                _context.Ratings.Remove(rating);
                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting rating", error = ex.Message });
            }
        }

        [HttpGet("doctor/{doctorId}/stats")]
        public async Task<ActionResult<object>> GetDoctorRatingStats(string doctorId)
        {
            try
            {
                var ratings = await _context.Ratings
                    .Where(r => r.DoctorId == doctorId)
                    .ToListAsync();

                if (!ratings.Any())
                {
                    return Ok(new
                    {
                        AverageRating = 0.0,
                        TotalRatings = 0,
                        RatingDistribution = new int[5] { 0, 0, 0, 0, 0 }
                    });
                }

                var averageRating = ratings.Average(r => r.RatingValue);
                var totalRatings = ratings.Count;

                var ratingDistribution = new int[5];
                foreach (var rating in ratings)
                {
                    if (rating.RatingValue >= 1 && rating.RatingValue <= 5)
                    {
                        ratingDistribution[rating.RatingValue - 1]++;
                    }
                }

                return Ok(new
                {
                    AverageRating = Math.Round(averageRating, 2),
                    TotalRatings = totalRatings,
                    RatingDistribution = ratingDistribution
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching rating stats", error = ex.Message });
            }
        }

        [HttpGet("my-ratings")]
        public async Task<ActionResult<List<RatingDto>>> GetMyRatings()
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                var ratings = await _context.Ratings
                    .Include(r => r.Patient)
                    .Include(r => r.Doctor)
                    .Include(r => r.Appointment)
                    .Where(r => r.PatientId == currentUserId)
                    .OrderByDescending(r => r.CreatedAt)
                    .Select(r => new RatingDto
                    {
                        Id = r.Id,
                        PatientId = r.PatientId,
                        PatientName = r.Patient != null ? r.Patient.FullName : "Unknown Patient",
                        DoctorId = r.DoctorId,
                        DoctorName = r.Doctor != null ? r.Doctor.FullName : "Unknown Doctor",
                        AppointmentId = r.AppointmentId,
                        RatingValue = r.RatingValue,
                        Review = r.Review,
                        CreatedAt = r.CreatedAt,
                        UpdatedAt = r.UpdatedAt
                    })
                    .ToListAsync();

                return Ok(ratings);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching your ratings", error = ex.Message });
            }
        }
    }
}
