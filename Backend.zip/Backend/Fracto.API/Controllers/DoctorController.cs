using Fracto.Core.DTOs;
using Fracto.Core.Entities;
using Fracto.Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Fracto.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DoctorController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public DoctorController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [HttpGet]
        public async Task<ActionResult<DoctorSearchResultDto>> GetDoctors([FromQuery] DoctorSearchDto searchDto)
        {
            try
            {
                var query = _context.Doctors
                    .Include(d => d.Specialization)
                    .Include(d => d.Ratings)
                    .Where(d => d.IsActive && d.IsAvailable);

                // Apply filters
                if (!string.IsNullOrEmpty(searchDto.City))
                {
                    query = query.Where(d => d.City != null && d.City.ToLower().Contains(searchDto.City.ToLower()));
                }

                if (searchDto.SpecializationId.HasValue)
                {
                    query = query.Where(d => d.SpecializationId == searchDto.SpecializationId.Value);
                }

                if (searchDto.MaxFee.HasValue)
                {
                    query = query.Where(d => d.ConsultationFee <= searchDto.MaxFee.Value);
                }

                if (searchDto.MinRating.HasValue)
                {
                    query = query.Where(d => d.Ratings.Any() && d.Ratings.Average(r => r.RatingValue) >= searchDto.MinRating.Value);
                }

                // Calculate total count before pagination
                var totalCount = await query.CountAsync();

                // Apply pagination
                var doctors = await query
                    .Skip((searchDto.Page - 1) * searchDto.PageSize)
                    .Take(searchDto.PageSize)
                    .Select(d => new DoctorDto
                    {
                        Id = d.Id,
                        FirstName = d.FirstName,
                        LastName = d.LastName,
                        Email = d.Email ?? string.Empty,
                        PhoneNumber = d.PhoneNumber,
                        Address = d.Address,
                        City = d.City,
                        ProfileImagePath = d.ProfileImagePath,
                        LicenseNumber = d.LicenseNumber,
                        Biography = d.Biography,
                        Hospital = d.Hospital,
                        Clinic = d.Clinic,
                        ConsultationFee = d.ConsultationFee,
                        ExperienceYears = d.ExperienceYears,
                        IsAvailable = d.IsAvailable,
                        StartTime = d.StartTime,
                        EndTime = d.EndTime,
                        Specialization = new SpecializationDto
                        {
                            Id = d.Specialization.Id,
                            Name = d.Specialization.Name,
                            Description = d.Specialization.Description,
                            IsActive = d.Specialization.IsActive,
                            CreatedAt = d.Specialization.CreatedAt
                        },
                        AverageRating = d.Ratings.Any() ? d.Ratings.Average(r => r.RatingValue) : 0,
                        TotalRatings = d.Ratings.Count
                    })
                    .ToListAsync();

                var totalPages = (int)Math.Ceiling((double)totalCount / searchDto.PageSize);

                return Ok(new DoctorSearchResultDto
                {
                    Doctors = doctors,
                    TotalCount = totalCount,
                    Page = searchDto.Page,
                    PageSize = searchDto.PageSize,
                    TotalPages = totalPages
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching doctors", error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<DoctorDto>> GetDoctor(string id)
        {
            try
            {
                var doctor = await _context.Doctors
                    .Include(d => d.Specialization)
                    .Include(d => d.Ratings)
                    .FirstOrDefaultAsync(d => d.Id == id && d.IsActive);

                if (doctor == null)
                {
                    return NotFound();
                }

                var doctorDto = new DoctorDto
                {
                    Id = doctor.Id,
                    FirstName = doctor.FirstName,
                    LastName = doctor.LastName,
                    Email = doctor.Email ?? string.Empty,
                    PhoneNumber = doctor.PhoneNumber,
                    Address = doctor.Address,
                    City = doctor.City,
                    ProfileImagePath = doctor.ProfileImagePath,
                    LicenseNumber = doctor.LicenseNumber,
                    Biography = doctor.Biography,
                    Hospital = doctor.Hospital,
                    Clinic = doctor.Clinic,
                    ConsultationFee = doctor.ConsultationFee,
                    ExperienceYears = doctor.ExperienceYears,
                    IsAvailable = doctor.IsAvailable,
                    StartTime = doctor.StartTime,
                    EndTime = doctor.EndTime,
                    Specialization = new SpecializationDto
                    {
                        Id = doctor.Specialization.Id,
                        Name = doctor.Specialization.Name,
                        Description = doctor.Specialization.Description,
                        IsActive = doctor.Specialization.IsActive,
                        CreatedAt = doctor.Specialization.CreatedAt
                    },
                    AverageRating = doctor.Ratings.Any() ? doctor.Ratings.Average(r => r.RatingValue) : 0,
                    TotalRatings = doctor.Ratings.Count
                };

                return Ok(doctorDto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching doctor", error = ex.Message });
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<DoctorDto>> CreateDoctor([FromBody] CreateDoctorDto createDoctorDto)
        {
            try
            {
                var specialization = await _context.Specializations.FindAsync(createDoctorDto.SpecializationId);
                if (specialization == null)
                {
                    return BadRequest("Invalid specialization");
                }

                var doctor = new Doctor
                {
                    UserName = createDoctorDto.Email,
                    Email = createDoctorDto.Email,
                    FirstName = createDoctorDto.FirstName,
                    LastName = createDoctorDto.LastName,
                    Address = createDoctorDto.Address,
                    City = createDoctorDto.City,
                    PhoneNumber = createDoctorDto.PhoneNumber,
                    LicenseNumber = createDoctorDto.LicenseNumber,
                    Biography = createDoctorDto.Biography,
                    Hospital = createDoctorDto.Hospital,
                    Clinic = createDoctorDto.Clinic,
                    ConsultationFee = createDoctorDto.ConsultationFee,
                    ExperienceYears = createDoctorDto.ExperienceYears,
                    StartTime = createDoctorDto.StartTime,
                    EndTime = createDoctorDto.EndTime,
                    SpecializationId = createDoctorDto.SpecializationId,
                    IsAvailable = true,
                    CreatedAt = DateTime.UtcNow
                };

                _context.Doctors.Add(doctor);
                await _context.SaveChangesAsync();

                var doctorDto = new DoctorDto
                {
                    Id = doctor.Id,
                    FirstName = doctor.FirstName,
                    LastName = doctor.LastName,
                    Email = doctor.Email ?? string.Empty,
                    PhoneNumber = doctor.PhoneNumber,
                    Address = doctor.Address,
                    City = doctor.City,
                    ProfileImagePath = doctor.ProfileImagePath,
                    LicenseNumber = doctor.LicenseNumber,
                    Biography = doctor.Biography,
                    Hospital = doctor.Hospital,
                    Clinic = doctor.Clinic,
                    ConsultationFee = doctor.ConsultationFee,
                    ExperienceYears = doctor.ExperienceYears,
                    IsAvailable = doctor.IsAvailable,
                    StartTime = doctor.StartTime,
                    EndTime = doctor.EndTime,
                    Specialization = new SpecializationDto
                    {
                        Id = specialization.Id,
                        Name = specialization.Name,
                        Description = specialization.Description,
                        IsActive = specialization.IsActive,
                        CreatedAt = specialization.CreatedAt
                    },
                    AverageRating = 0,
                    TotalRatings = 0
                };

                return CreatedAtAction(nameof(GetDoctor), new { id = doctor.Id }, doctorDto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while creating doctor", error = ex.Message });
            }
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Doctor")]
        public async Task<ActionResult> UpdateDoctor(string id, [FromBody] UpdateDoctorDto updateDoctorDto)
        {
            try
            {
                var doctor = await _context.Doctors.FindAsync(id);
                if (doctor == null)
                {
                    return NotFound();
                }

                // Check if the current user is the doctor or an admin
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var isAdmin = User.IsInRole("Admin");
                
                if (!isAdmin && currentUserId != id)
                {
                    return Forbid();
                }

                if (updateDoctorDto.Biography != null)
                    doctor.Biography = updateDoctorDto.Biography;
                if (updateDoctorDto.Hospital != null)
                    doctor.Hospital = updateDoctorDto.Hospital;
                if (updateDoctorDto.Clinic != null)
                    doctor.Clinic = updateDoctorDto.Clinic;
                if (updateDoctorDto.ConsultationFee.HasValue)
                    doctor.ConsultationFee = updateDoctorDto.ConsultationFee.Value;
                if (updateDoctorDto.ExperienceYears.HasValue)
                    doctor.ExperienceYears = updateDoctorDto.ExperienceYears.Value;
                if (updateDoctorDto.StartTime.HasValue)
                    doctor.StartTime = updateDoctorDto.StartTime.Value;
                if (updateDoctorDto.EndTime.HasValue)
                    doctor.EndTime = updateDoctorDto.EndTime.Value;
                if (updateDoctorDto.IsAvailable.HasValue)
                    doctor.IsAvailable = updateDoctorDto.IsAvailable.Value;

                doctor.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating doctor", error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> DeleteDoctor(string id)
        {
            try
            {
                var doctor = await _context.Doctors.FindAsync(id);
                if (doctor == null)
                {
                    return NotFound();
                }

                doctor.IsActive = false;
                doctor.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting doctor", error = ex.Message });
            }
        }

        [HttpGet("{id}/time-slots")]
        public async Task<ActionResult<AvailableTimeSlotsDto>> GetAvailableTimeSlots(string id, [FromQuery] DateTime date)
        {
            try
            {
                var doctor = await _context.Doctors
                    .Include(d => d.TimeSlots.Where(ts => ts.Date == date))
                    .FirstOrDefaultAsync(d => d.Id == id && d.IsActive);

                if (doctor == null)
                {
                    return NotFound();
                }

                var timeSlots = doctor.TimeSlots
                    .Where(ts => ts.IsAvailable && !ts.IsBooked)
                    .Select(ts => new TimeSlotDto
                    {
                        Id = ts.Id,
                        Date = ts.Date,
                        StartTime = ts.StartTime,
                        EndTime = ts.EndTime,
                        IsAvailable = ts.IsAvailable,
                        IsBooked = ts.IsBooked
                    })
                    .ToList();

                var result = new AvailableTimeSlotsDto
                {
                    DoctorId = int.Parse(doctor.Id),
                    DoctorName = doctor.FullName,
                    Date = date,
                    TimeSlots = timeSlots
                };

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching time slots", error = ex.Message });
            }
        }

        [HttpGet("specializations")]
        public async Task<ActionResult<List<SpecializationDto>>> GetSpecializations()
        {
            try
            {
                var specializations = await _context.Specializations
                    .Where(s => s.IsActive)
                    .Select(s => new SpecializationDto
                    {
                        Id = s.Id,
                        Name = s.Name,
                        Description = s.Description,
                        IsActive = s.IsActive,
                        CreatedAt = s.CreatedAt
                    })
                    .ToListAsync();

                return Ok(specializations);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching specializations", error = ex.Message });
            }
        }
    }
}








