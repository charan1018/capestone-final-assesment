using Fracto.Core.Entities;
using Fracto.Infrastructure.Data;
using Fracto.API.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { 
        Title = "Fracto Appointment API", 
        Version = "v1",
        Description = "API for managing doctor appointments"
    });
    
    // Add JWT authentication to Swagger
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
    
    Console.WriteLine("SwaggerGen configured successfully");
});

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngularApp", policy =>
    {
        policy.WithOrigins(builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? new string[0])
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });
});

// Add DbContext
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Add Identity
builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    options.Password.RequireDigit = true;
    options.Password.RequireLowercase = true;
    options.Password.RequireUppercase = true;
    options.Password.RequireNonAlphanumeric = true;
    options.Password.RequiredLength = 8;
    options.User.RequireUniqueEmail = true;
})
.AddEntityFrameworkStores<ApplicationDbContext>()
.AddDefaultTokenProviders();

// Add JWT Authentication
var jwtSettings = builder.Configuration.GetSection("JwtSettings");
var key = Encoding.UTF8.GetBytes(jwtSettings["SecretKey"] ?? throw new InvalidOperationException("JWT Secret Key not found"));

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = jwtSettings["Issuer"],
        ValidAudience = jwtSettings["Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ClockSkew = TimeSpan.Zero
    };
});

// Add AutoMapper
builder.Services.AddAutoMapper(typeof(Program));

// Add Services
builder.Services.AddScoped<IJwtService, JwtService>();

// Add Authorization
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("RequireAdminRole", policy => policy.RequireRole("Admin"));
    options.AddPolicy("RequireDoctorRole", policy => policy.RequireRole("Doctor"));
    options.AddPolicy("RequireUserRole", policy => policy.RequireRole("User"));
});

var app = builder.Build();

Console.WriteLine("Application built successfully");
Console.WriteLine("Environment: " + app.Environment.EnvironmentName);
Console.WriteLine("Starting to configure HTTP pipeline...");

// Configure the HTTP request pipeline.
Console.WriteLine("Configuring Swagger...");
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Fracto Appointment API v1");
    c.RoutePrefix = "swagger";
    c.DocumentTitle = "Fracto Appointment API";
});
Console.WriteLine("Swagger configured successfully");

app.UseHttpsRedirection();

app.UseCors("AllowAngularApp");

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

// Add a simple health check endpoint
app.MapGet("/health", () => "API is running!");
app.MapGet("/", () => "Fracto Appointment API is running! Navigate to /swagger for API documentation.");
app.MapGet("/test-swagger", () => "Swagger test endpoint working!");

// Ensure database is created and seed baseline data
try
{
    Console.WriteLine("Attempting to create database...");
    using (var scope = app.Services.CreateScope())
    {
        var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        context.Database.EnsureCreated();
        Console.WriteLine("Database created/verified successfully");

        var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

        // Seed roles
        string[] roles = new[] { "Admin", "Doctor", "User" };
        foreach (var role in roles)
        {
            if (!roleManager.RoleExistsAsync(role).GetAwaiter().GetResult())
            {
                var roleResult = roleManager.CreateAsync(new IdentityRole(role)).GetAwaiter().GetResult();
                if (!roleResult.Succeeded)
                {
                    Console.WriteLine($"Failed creating role {role}: {string.Join(", ", roleResult.Errors.Select(e => e.Description))}");
                }
            }
        }

        // Seed admin user
        var adminEmail = "admin@fracto.local";
        var adminUser = userManager.FindByEmailAsync(adminEmail).GetAwaiter().GetResult();
        if (adminUser == null)
        {
            var admin = new ApplicationUser
            {
                UserName = adminEmail,
                Email = adminEmail,
                FirstName = "System",
                LastName = "Admin",
                City = "",
                Address = "",
                CreatedAt = DateTime.UtcNow,
                IsActive = true
            };
            var created = userManager.CreateAsync(admin, "Admin@12345").GetAwaiter().GetResult();
            if (created.Succeeded)
            {
                userManager.AddToRoleAsync(admin, "Admin").GetAwaiter().GetResult();
                Console.WriteLine("Admin user created");
            }
            else
            {
                Console.WriteLine($"Failed creating admin user: {string.Join(", ", created.Errors.Select(e => e.Description))}");
            }
        }

        // Seed sample doctors if none exist
        if (!context.Doctors.Any())
        {
            Console.WriteLine("Seeding sample doctors...");
            var utcNow = DateTime.UtcNow;
            var start = new TimeSpan(9, 0, 0);
            var end = new TimeSpan(17, 0, 0);

            var specializations = context.Specializations.Take(5).ToList();
            if (specializations.Count == 0)
            {
                Console.WriteLine("No specializations found to attach to doctors. Skipping doctor seed.");
            }
            else
            {
                for (int i = 0; i < specializations.Count; i++)
                {
                    var spec = specializations[i];
                    var email = $"doctor{i + 1}@fracto.local";
                    var doctor = new Doctor
                    {
                        UserName = email,
                        Email = email,
                        FirstName = $"Doctor{i + 1}",
                        LastName = spec.Name,
                        City = "Metropolis",
                        Address = "123 Health St",
                        PhoneNumber = "+1-555-0000",
                        CreatedAt = utcNow,
                        IsActive = true,
                        LicenseNumber = $"LIC-{1000 + i}",
                        Biography = "Experienced specialist.",
                        Hospital = "General Hospital",
                        Clinic = "Fracto Clinic",
                        ConsultationFee = 500 + i * 50,
                        ExperienceYears = 5 + i,
                        StartTime = start,
                        EndTime = end,
                        IsAvailable = true,
                        SpecializationId = spec.Id
                    };

                    var createResult = userManager.CreateAsync(doctor, "Doctor@12345").GetAwaiter().GetResult();
                    if (createResult.Succeeded)
                    {
                        userManager.AddToRoleAsync(doctor, "Doctor").GetAwaiter().GetResult();

                        // Add a few time slots for the next 3 days
                        for (int d = 0; d < 3; d++)
                        {
                            var date = DateOnly.FromDateTime(DateTime.UtcNow.Date.AddDays(d));
                            // 9-10, 10-11, 11-12
                            for (int h = 9; h <= 11; h++)
                            {
                                context.TimeSlots.Add(new TimeSlot
                                {
                                    DoctorId = doctor.Id,
                                    Date = DateTime.UtcNow.Date.AddDays(d),
                                    StartTime = new TimeSpan(h, 0, 0),
                                    EndTime = new TimeSpan(h + 1, 0, 0),
                                    IsAvailable = true,
                                    IsBooked = false,
                                    CreatedAt = utcNow
                                });
                            }
                        }
                        context.SaveChanges();
                    }
                    else
                    {
                        Console.WriteLine($"Failed creating doctor {email}: {string.Join(", ", createResult.Errors.Select(e => e.Description))}");
                    }
                }
            }
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine($"Error creating database: {ex.Message}");
    Console.WriteLine($"Stack trace: {ex.StackTrace}");
    Console.WriteLine("Continuing without database...");
    // Continue running the app even if database creation fails
}

app.Run();
