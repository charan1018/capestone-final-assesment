using System.ComponentModel.DataAnnotations;
using Fracto.Core.Entities;

namespace Fracto.Core.DTOs
{
    public class AppointmentDto
    {
        public int Id { get; set; }
        public string PatientId { get; set; } = string.Empty;
        public string PatientName { get; set; } = string.Empty;
        public string DoctorId { get; set; } = string.Empty;
        public string DoctorName { get; set; } = string.Empty;
        public string SpecializationName { get; set; } = string.Empty;
        public DateTime AppointmentDate { get; set; }
        public TimeSpan AppointmentTime { get; set; }
        public string? Symptoms { get; set; }
        public string? Notes { get; set; }
        public AppointmentStatus Status { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public DateTime? CancelledAt { get; set; }
        public string? CancellationReason { get; set; }
        public decimal ConsultationFee { get; set; }
    }

    public class CreateAppointmentDto
    {
        [Required]
        public string DoctorId { get; set; } = string.Empty;

        [Required]
        public int TimeSlotId { get; set; }

        [Required]
        public DateTime AppointmentDate { get; set; }

        [Required]
        public TimeSpan AppointmentTime { get; set; }

        [MaxLength(500)]
        public string? Symptoms { get; set; }

        [MaxLength(500)]
        public string? Notes { get; set; }
    }

    public class UpdateAppointmentDto
    {
        [MaxLength(500)]
        public string? Symptoms { get; set; }

        [MaxLength(500)]
        public string? Notes { get; set; }

        public AppointmentStatus? Status { get; set; }

        [MaxLength(200)]
        public string? CancellationReason { get; set; }
    }

    public class AppointmentSearchDto
    {
        public string? PatientId { get; set; }
        public string? DoctorId { get; set; }
        public AppointmentStatus? Status { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }

    public class AppointmentSearchResultDto
    {
        public List<AppointmentDto> Appointments { get; set; } = new List<AppointmentDto>();
        public int TotalCount { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalPages { get; set; }
    }

    public class TimeSlotDto
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public bool IsAvailable { get; set; }
        public bool IsBooked { get; set; }
    }

    public class AvailableTimeSlotsDto
    {
        public int DoctorId { get; set; }
        public string DoctorName { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public List<TimeSlotDto> TimeSlots { get; set; } = new List<TimeSlotDto>();
    }
}
