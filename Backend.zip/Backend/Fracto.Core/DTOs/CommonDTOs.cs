using System.ComponentModel.DataAnnotations;

namespace Fracto.Core.DTOs
{
    public class SpecializationDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class CreateSpecializationDto
    {
        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Description { get; set; }
    }

    public class UpdateSpecializationDto
    {
        [MaxLength(100)]
        public string? Name { get; set; }

        [MaxLength(500)]
        public string? Description { get; set; }

        public bool? IsActive { get; set; }
    }

    public class RatingDto
    {
        public int Id { get; set; }
        public string PatientId { get; set; } = string.Empty;
        public string PatientName { get; set; } = string.Empty;
        public string DoctorId { get; set; } = string.Empty;
        public string DoctorName { get; set; } = string.Empty;
        public int AppointmentId { get; set; }
        public int RatingValue { get; set; }
        public string? Review { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }

    public class CreateRatingDto
    {
        [Required]
        public string DoctorId { get; set; } = string.Empty;

        [Required]
        public int AppointmentId { get; set; }

        [Required]
        [Range(1, 5)]
        public int RatingValue { get; set; }

        [MaxLength(1000)]
        public string? Review { get; set; }
    }

    public class UpdateRatingDto
    {
        [Range(1, 5)]
        public int? RatingValue { get; set; }

        [MaxLength(1000)]
        public string? Review { get; set; }
    }

    public class ApiResponseDto<T>
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; } = string.Empty;
        public T? Data { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
    }

    public class PaginatedResponseDto<T>
    {
        public List<T> Items { get; set; } = new List<T>();
        public int TotalCount { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalPages { get; set; }
        public bool HasPreviousPage => Page > 1;
        public bool HasNextPage => Page < TotalPages;
    }
}
