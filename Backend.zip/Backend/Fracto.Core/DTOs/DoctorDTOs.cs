using System.ComponentModel.DataAnnotations;

namespace Fracto.Core.DTOs
{
    public class DoctorDto
    {
        public string Id { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string? PhoneNumber { get; set; }
        public string? Address { get; set; }
        public string? City { get; set; }
        public string? ProfileImagePath { get; set; }
        public string LicenseNumber { get; set; } = string.Empty;
        public string? Biography { get; set; }
        public string? Hospital { get; set; }
        public string? Clinic { get; set; }
        public decimal ConsultationFee { get; set; }
        public int ExperienceYears { get; set; }
        public bool IsAvailable { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public SpecializationDto Specialization { get; set; } = null!;
        public double AverageRating { get; set; }
        public int TotalRatings { get; set; }
    }

    public class CreateDoctorDto
    {
        [Required]
        [MaxLength(100)]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string LastName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        [MinLength(6)]
        public string Password { get; set; } = string.Empty;

        [MaxLength(20)]
        public string? PhoneNumber { get; set; }

        [MaxLength(200)]
        public string? Address { get; set; }

        [MaxLength(50)]
        public string? City { get; set; }

        [Required]
        [MaxLength(100)]
        public string LicenseNumber { get; set; } = string.Empty;

        [MaxLength(1000)]
        public string? Biography { get; set; }

        [MaxLength(200)]
        public string? Hospital { get; set; }

        [MaxLength(200)]
        public string? Clinic { get; set; }

        [Range(0, double.MaxValue)]
        public decimal ConsultationFee { get; set; }

        [Range(0, 50)]
        public int ExperienceYears { get; set; }

        public TimeSpan StartTime { get; set; }

        public TimeSpan EndTime { get; set; }

        [Required]
        public int SpecializationId { get; set; }
    }

    public class UpdateDoctorDto
    {
        [MaxLength(1000)]
        public string? Biography { get; set; }

        [MaxLength(200)]
        public string? Hospital { get; set; }

        [MaxLength(200)]
        public string? Clinic { get; set; }

        [Range(0, double.MaxValue)]
        public decimal? ConsultationFee { get; set; }

        [Range(0, 50)]
        public int? ExperienceYears { get; set; }

        public TimeSpan? StartTime { get; set; }

        public TimeSpan? EndTime { get; set; }

        public bool? IsAvailable { get; set; }
    }

    public class DoctorSearchDto
    {
        public string? City { get; set; }
        public int? SpecializationId { get; set; }
        public decimal? MaxFee { get; set; }
        public int? MinRating { get; set; }
        public DateTime? AvailableDate { get; set; }
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }

    public class DoctorSearchResultDto
    {
        public List<DoctorDto> Doctors { get; set; } = new List<DoctorDto>();
        public int TotalCount { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalPages { get; set; }
    }
}








