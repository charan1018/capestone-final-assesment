using System.ComponentModel.DataAnnotations;

namespace Fracto.Core.Entities
{
    public class Doctor : ApplicationUser
    {
        [Required]
        [MaxLength(100)]
        public string LicenseNumber { get; set; } = string.Empty;

        [MaxLength(1000)]
        public string? Biography { get; set; }

        [MaxLength(200)]
        public string? Hospital { get; set; }

        [MaxLength(200)]
        public string? Clinic { get; set; }

        public decimal ConsultationFee { get; set; }

        public int ExperienceYears { get; set; }

        public bool IsAvailable { get; set; } = true;

        public TimeSpan StartTime { get; set; }

        public TimeSpan EndTime { get; set; }

        public int SpecializationId { get; set; }

        // Navigation properties
        public virtual Specialization Specialization { get; set; } = null!;
        public virtual ICollection<TimeSlot> TimeSlots { get; set; } = new List<TimeSlot>();
    }
}
