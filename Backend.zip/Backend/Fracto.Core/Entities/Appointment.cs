using System.ComponentModel.DataAnnotations;

namespace Fracto.Core.Entities
{
    public class Appointment
    {
        public int Id { get; set; }

        public string PatientId { get; set; } = string.Empty;

        public string DoctorId { get; set; } = string.Empty;

        public int TimeSlotId { get; set; }

        public DateTime AppointmentDate { get; set; }

        public TimeSpan AppointmentTime { get; set; }

        [MaxLength(500)]
        public string? Symptoms { get; set; }

        [MaxLength(500)]
        public string? Notes { get; set; }

        public AppointmentStatus Status { get; set; } = AppointmentStatus.Pending;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? UpdatedAt { get; set; }

        public DateTime? CancelledAt { get; set; }

        [MaxLength(200)]
        public string? CancellationReason { get; set; }

        // Navigation properties
        public virtual ApplicationUser Patient { get; set; } = null!;
        public virtual Doctor Doctor { get; set; } = null!;
        public virtual TimeSlot TimeSlot { get; set; } = null!;
    }

    public enum AppointmentStatus
    {
        Pending = 0,
        Confirmed = 1,
        Completed = 2,
        Cancelled = 3,
        NoShow = 4
    }
}
