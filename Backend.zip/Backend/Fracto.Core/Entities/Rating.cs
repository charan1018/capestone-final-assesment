using System.ComponentModel.DataAnnotations;

namespace Fracto.Core.Entities
{
    public class Rating
    {
        public int Id { get; set; }

        public string PatientId { get; set; } = string.Empty;

        public string DoctorId { get; set; } = string.Empty;

        public int AppointmentId { get; set; }

        [Range(1, 5)]
        public int RatingValue { get; set; }

        [MaxLength(1000)]
        public string? Review { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? UpdatedAt { get; set; }

        // Navigation properties
        public virtual ApplicationUser Patient { get; set; } = null!;
        public virtual Doctor Doctor { get; set; } = null!;
        public virtual Appointment Appointment { get; set; } = null!;
    }
}
