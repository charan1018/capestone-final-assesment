using System.ComponentModel.DataAnnotations;

namespace Fracto.Core.Entities
{
    public class TimeSlot
    {
        public int Id { get; set; }

        public string DoctorId { get; set; } = string.Empty;

        public DateTime Date { get; set; }

        public TimeSpan StartTime { get; set; }

        public TimeSpan EndTime { get; set; }

        public bool IsAvailable { get; set; } = true;

        public bool IsBooked { get; set; } = false;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation properties
        public virtual Doctor Doctor { get; set; } = null!;
        public virtual Appointment? Appointment { get; set; }
    }
}
