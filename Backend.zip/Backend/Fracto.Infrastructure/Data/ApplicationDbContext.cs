using Fracto.Core.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Fracto.Infrastructure.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Specialization> Specializations { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
        public DbSet<TimeSlot> TimeSlots { get; set; }
        public DbSet<Rating> Ratings { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configure ApplicationUser
            builder.Entity<ApplicationUser>(entity =>
            {
                entity.ToTable("Users");
                entity.Property(e => e.FirstName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.LastName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Address).HasMaxLength(200);
                entity.Property(e => e.City).HasMaxLength(50);
                entity.Property(e => e.PhoneNumber).HasMaxLength(20);
                entity.Property(e => e.ProfileImagePath).HasMaxLength(500);
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            });

            // Configure Doctor
            builder.Entity<Doctor>(entity =>
            {
                entity.ToTable("Doctors");
                entity.Property(e => e.LicenseNumber).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Biography).HasMaxLength(1000);
                entity.Property(e => e.Hospital).HasMaxLength(200);
                entity.Property(e => e.Clinic).HasMaxLength(200);
                entity.Property(e => e.ConsultationFee).HasColumnType("decimal(18,2)");
                entity.Property(e => e.StartTime).HasColumnType("time");
                entity.Property(e => e.EndTime).HasColumnType("time");
                
                entity.HasOne(d => d.Specialization)
                    .WithMany(s => s.Doctors)
                    .HasForeignKey(d => d.SpecializationId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Configure Specialization
            builder.Entity<Specialization>(entity =>
            {
                entity.ToTable("Specializations");
                entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            });

            // Configure TimeSlot
            builder.Entity<TimeSlot>(entity =>
            {
                entity.ToTable("TimeSlots");
                entity.Property(e => e.Date).HasColumnType("date");
                entity.Property(e => e.StartTime).HasColumnType("time");
                entity.Property(e => e.EndTime).HasColumnType("time");
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
                
                entity.HasOne(ts => ts.Doctor)
                    .WithMany(d => d.TimeSlots)
                    .HasForeignKey(ts => ts.DoctorId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // Configure Appointment
            builder.Entity<Appointment>(entity =>
            {
                entity.ToTable("Appointments");
                entity.Property(e => e.AppointmentDate).HasColumnType("date");
                entity.Property(e => e.AppointmentTime).HasColumnType("time");
                entity.Property(e => e.Symptoms).HasMaxLength(500);
                entity.Property(e => e.Notes).HasMaxLength(500);
                entity.Property(e => e.CancellationReason).HasMaxLength(200);
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
                
                entity.HasOne(a => a.Patient)
                    .WithMany(u => u.Appointments)
                    .HasForeignKey(a => a.PatientId)
                    .OnDelete(DeleteBehavior.Restrict);
                
                entity.HasOne(a => a.Doctor)
                    .WithMany()
                    .HasForeignKey(a => a.DoctorId)
                    .OnDelete(DeleteBehavior.Restrict);
                
                entity.HasOne(a => a.TimeSlot)
                    .WithOne(ts => ts.Appointment)
                    .HasForeignKey<Appointment>(a => a.TimeSlotId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Configure Rating
            builder.Entity<Rating>(entity =>
            {
                entity.ToTable("Ratings");
                entity.Property(e => e.RatingValue).IsRequired();
                entity.Property(e => e.Review).HasMaxLength(1000);
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
                
                entity.HasOne(r => r.Patient)
                    .WithMany(u => u.Ratings)
                    .HasForeignKey(r => r.PatientId)
                    .OnDelete(DeleteBehavior.Restrict);
                
                entity.HasOne(r => r.Doctor)
                    .WithMany()
                    .HasForeignKey(r => r.DoctorId)
                    .OnDelete(DeleteBehavior.Restrict);
                
                entity.HasOne(r => r.Appointment)
                    .WithMany()
                    .HasForeignKey(r => r.AppointmentId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Seed data
            SeedData(builder);
        }

        private void SeedData(ModelBuilder builder)
        {
            // Seed Specializations
            builder.Entity<Specialization>().HasData(
                new Specialization { Id = 1, Name = "Cardiology", Description = "Heart and cardiovascular system", IsActive = true, CreatedAt = DateTime.UtcNow },
                new Specialization { Id = 2, Name = "Dermatology", Description = "Skin, hair, and nails", IsActive = true, CreatedAt = DateTime.UtcNow },
                new Specialization { Id = 3, Name = "Neurology", Description = "Nervous system and brain", IsActive = true, CreatedAt = DateTime.UtcNow },
                new Specialization { Id = 4, Name = "Orthopedics", Description = "Bones, joints, and muscles", IsActive = true, CreatedAt = DateTime.UtcNow },
                new Specialization { Id = 5, Name = "Pediatrics", Description = "Children's health", IsActive = true, CreatedAt = DateTime.UtcNow },
                new Specialization { Id = 6, Name = "Psychiatry", Description = "Mental health", IsActive = true, CreatedAt = DateTime.UtcNow },
                new Specialization { Id = 7, Name = "General Medicine", Description = "General health and wellness", IsActive = true, CreatedAt = DateTime.UtcNow }
            );
        }
    }
}
