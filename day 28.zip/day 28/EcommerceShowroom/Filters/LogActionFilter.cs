using Microsoft.AspNetCore.Mvc.Filters;

namespace EcommerceShowroom.Filters
{
    public class LogActionFilter : IActionFilter
    {
        public void OnActionExecuting(ActionExecutingContext context)
        {
            var username = context.HttpContext.Session.GetString("Username") ?? "Guest";
            Console.WriteLine($"[LOG] {username} accessed {context.HttpContext.Request.Path}");
        }

        public void OnActionExecuted(ActionExecutedContext context) { }
    }
}
