using Microsoft.AspNetCore.Mvc;
using EcommerceShowroom.Models;
using System.Text.Json;

namespace EcommerceShowroom.Controllers
{
    public class CartController : Controller
    {
        private List<Product> products = new()
        {
            new Product{ Id=1, Name="Product 1", Price=100, ImageUrl="/images/p1.png"},
            new Product{ Id=2, Name="Product 2", Price=200, ImageUrl="/images/p2.png"},
            new Product{ Id=3, Name="Product 3", Price=300, ImageUrl="/images/p3.png"},
            new Product{ Id=4, Name="Product 4", Price=400, ImageUrl="/images/p4.png"},
        };

        public IActionResult Index()
        {
            var cart = GetCart();
            return View(cart);
        }

        public IActionResult Add(int id)
        {
            var product = products.FirstOrDefault(p => p.Id == id);
            var cart = GetCart();

            var item = cart.FirstOrDefault(c => c.Product.Id == id);
            if (item != null)
                item.Quantity++;
            else
                cart.Add(new CartItem { Product = product, Quantity = 1 });

            SaveCart(cart);
            return RedirectToAction("Index");
        }

        public IActionResult Remove(int id)
        {
            var cart = GetCart();
            cart.RemoveAll(c => c.Product.Id == id);
            SaveCart(cart);
            return RedirectToAction("Index");
        }

        public IActionResult Checkout()
        {
            var cart = GetCart();
            return View(cart);
        }

        private List<CartItem> GetCart()
        {
            var session = HttpContext.Session.GetString("Cart");
            return session == null ? new List<CartItem>() : JsonSerializer.Deserialize<List<CartItem>>(session);
        }

        private void SaveCart(List<CartItem> cart)
        {
            HttpContext.Session.SetString("Cart", JsonSerializer.Serialize(cart));
        }
    }
}
