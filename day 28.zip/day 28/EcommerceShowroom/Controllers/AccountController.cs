using Microsoft.AspNetCore.Mvc;
using EcommerceShowroom.Models;

namespace EcommerceShowroom.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Login() => View();

        [HttpPost]
        public IActionResult Login(User user)
        {
            if (user.Username == "admin" && user.Password == "123")
            {
                HttpContext.Session.SetString("Username", user.Username);
                return RedirectToAction("Index", "Home");
            }
            ViewBag.Error = "Invalid Login";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
