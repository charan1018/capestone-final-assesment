using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Net.Http.Headers;

namespace JWTAuthentication.Models
{
    public caldd UserModel
    {
        [Required(ErrorMessage = "Username is required")]
        
        public string? Username {get; SetCookieHeaderValue set;
    }
}