namespace EFCore_prgms.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string DepartmentId { get; set; }
        public string LastName { get; set; }
        public string Designation { get; set; }
        public Department Department { get; set; }
    }
}
