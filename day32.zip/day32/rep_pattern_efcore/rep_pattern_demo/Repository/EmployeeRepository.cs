using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using rep_pattern_demo.Models;
using rep_pattern_demo.Repository;
using RepositoyyPatternDemo.Repository;


namespace rep_pattern_demo.Repository
{
    public class EmployeeRepository : IEmployeeRepository, IDisposable
    {
        private EmployeeContext _context;
        private bool _disposed = false;

        public EmployeeRepository(EmployeeContext context)
        {
            _context = context;
        }
        public IEnumerable<Employee> GetAllEmployees()
        {
            return _context.Employees.ToList();
        }

        public Employee GetEmployeeById(int employeeId)
        {
            return _context.Employees.Find(employeeId);
        }

        public int AddEmployee(Employee employeeEntity)
        {
            int result = -1;
            if (employeeEntity == null)
            {
                _context.Employees.Add(employeeEntity);
                _context.SaveChanges();
                result = employeeEntity.EmployeeId;
            }
            return result;
        }

        public int UpdateEmployee(Employee employeeEntity)
        {
            int result = -1;
            if (employeeEntity != null)
            {
                _context.Entry(employeeEntity).State = EntityState.Modified;
                _context.SaveChanges();
                result = employeeEntity.EmployeeId;
            }
            return result;
        }

        public int DeleteEmployee(int employeeId)
        { 
            int result = -1;
            var employeeEntity = _context.Employees.Find(employeeId);
            if (employeeEntity != null)
            {
                _context.Employees.Remove(employeeEntity);
                _context.SaveChanges();
                result = employeeEntity.EmployeeId;
            }
            return result;
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}