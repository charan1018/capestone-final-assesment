using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using rep_pattern_demo.Models;

namespace RepositoyyPatternDemo.Repository
{
    public interface IEmployeeRepository : IDisposable
    {
        IEnumerable<Employee> GetAllEmployees();
        Employee GetEmployeeById(int employeeId);
        int AddEmployee(Employee employeeEntity);
        int UpdateEmployee(Employee employeeENtity);
        int DeleteEmployee(int employeeId);
        
    }
}
