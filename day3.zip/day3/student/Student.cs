﻿using System;

namespace StudentProgram;  // Package
class Student
{
    public string Name { get; set; }
    public int Age { get; set; }
    public int[] SubjectMarks { get; set; }
}


