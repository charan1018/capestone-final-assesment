﻿using ReportingSystem.Models;

namespace ReportingSystem.Interfaces
{
    public interface IReportGenerator
    {
        string GenerateReport();
    }

}
