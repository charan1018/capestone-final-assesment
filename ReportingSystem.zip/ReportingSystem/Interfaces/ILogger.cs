﻿using System;

namespace ReportingSystem.Interfaces
{
    public interface ILogger
    {
        void Log(string message);
    }
}
