﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReportingSystem.Interfaces;  // ✅ assuming namespace for interfaces
using ReportingSystem.Models;      // if using Report
using ReportingSystem.Utils;

namespace ReportingSystem.Interfaces
{
    public interface IReportSaver
    {
        void SaveReport(string content, string filename);
    }
}
