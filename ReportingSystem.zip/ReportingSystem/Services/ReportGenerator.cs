﻿using ReportingSystem.Interfaces;
using ReportingSystem.Models;

namespace ReportingSystem.Services
{
    public class ReportGenerator : IReportGenerator
    {
        private readonly Report _report;
        private readonly IFormatter _formatter;

        public ReportGenerator(Report report, IFormatter formatter)
        {
            _report = report;
            _formatter = formatter;
        }

        public string GenerateReport()
        {
            return _formatter.Format(_report.GetDetails());
        }
    }
}
