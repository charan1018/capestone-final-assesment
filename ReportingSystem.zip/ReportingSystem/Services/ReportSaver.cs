﻿using System.IO;
using ReportingSystem.Interfaces;

namespace ReportingSystem.Services
{
    public class ReportSaver : IReportSaver
    {
        public void SaveReport(string content, string fileName)
        {
            File.WriteAllText(fileName, content);
        }
    }
}
