﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReportingSystem.Interfaces;

namespace ReportingSystem.Services
{
    public class ReportService
    {
        private readonly IReportGenerator _generator;
        private readonly IReportSaver _saver;
        private readonly ILogger _logger;

        public ReportService(IReportGenerator generator, IReportSaver saver, ILogger logger)
        {
            _generator = generator;
            _saver = saver;
            _logger = logger;
        }

        public void ProcessReport(string fileName)
        {
            _logger.Log("Generating report...");
            var content = _generator.GenerateReport();

            _logger.Log("Saving report...");
            _saver.SaveReport(content, fileName);

            _logger.Log("Report saved successfully.");
        }
    }
}

