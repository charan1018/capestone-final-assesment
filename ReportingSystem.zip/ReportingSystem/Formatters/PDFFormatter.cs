﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReportingSystem.Interfaces;

namespace ReportingSystem.Formatters
{
    public class PDFFormatter : IFormatter
    {
        public string Format(string content)
        {
            return $"PDF Report: {content}";
        }
    }
}
