﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReportingSystem.Interfaces;

namespace ReportingSystem.Formatters
{
    public class ExcelFormatter : IFormatter
    {
        public string Format(string content)
        {
            return $"Excel Report: {content}";
        }
    }
}
