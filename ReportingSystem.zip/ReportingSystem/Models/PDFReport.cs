﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReportingSystem.Models
{
    
        public class PDFReport : Report
        {
            public PDFReport(string title, string content) : base(title, content) { }

            public override string GetDetails()
            {
                return $"[PDF Report]\nTitle: {Title}\nContent: {Content}";
            }
        }
    
}
