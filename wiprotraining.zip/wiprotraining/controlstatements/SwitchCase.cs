class SwitchCaseProgram
{

 public void PrimeCheck()
 {


 }


    // static void Main()
    // {
    //     Console.WriteLine("Enter your choice 1 for prime ,2. even  to 5)");
    //     int choice  = Convert.ToInt32(Console.ReadLine());
   
          
    //     switch(choice)
    //     {
    //         case 1:
    //             Console.WriteLine("Enter the no");
              //      LoopProgram p = new LoopProgram();
                //    p.PrimeCheck();
    //
    //             break;
    //         case 2:
    //             Console.WriteLine("Product is deleted from a cart");
    //             break;
    //         case 3:
    //             Console.WriteLine("Total amount to pay");
    //             break;
    //         case 4:
    //             Console.WriteLine("Successfully you have purchased");
    //             break;
    //         case 5:
    //             break;
    //             //default is optional
    //          default:
    //             Console.WriteLine("All Days are lucky(but you may try by entering choices b/w 1 to 5)");
    //             break;

    //     }
        
    // }
}

//WAP to take a choice as an input from the user to add , delete, view and update the student details:
//WAP to take a choice as an input 1 for prime no to check , 2 for odd no to check and 3 for even no to check 
