using System;
using System.Collections.Generic;
using System.Linq;

string connectionString =
"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=AdoDemo_wipro;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

using (SqlConnection connection = new SqlConnection(connectionString))
{
    connection.Open();
    Console.WriteLine("Connection opened successfully.");

    string query = "SELECT * FROM Employees";
    using (SqlCommand command = new SqlCommand(query, connection))
    {
        using (SqlDataReader reader = command.ExecuteReader())
        {
            while (reader.Read())
            {
                Console.WriteLine($"ID: {reader["Id"]}, Name: {reader["Name"]}, Position: {reader["Position"]}");
            }
        }
    }

    connection.Close();
    Console.WriteLine("Connection closed.");
}

