export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber?: string;
  address?: string;
  city?: string;
  dateOfBirth: Date;
  profileImagePath?: string;
  roles: string[];
}

export interface Doctor extends User {
  licenseNumber: string;
  biography?: string;
  hospital?: string;
  clinic?: string;
  consultationFee: number;
  experienceYears: number;
  isAvailable: boolean;
  startTime: string;
  endTime: string;
  specializationId: number;
  specialization?: Specialization;
  averageRating: number;
  totalRatings: number;
}

export interface Specialization {
  id: number;
  name: string;
  description?: string;
  isActive: boolean;
  createdAt: Date;
}

export interface AuthResponse {
  isSuccess: boolean;
  message: string;
  token?: string;
  expiresAt?: Date;
  user?: User;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  confirmPassword: string;
  address?: string;
  city?: string;
  phoneNumber?: string;
  dateOfBirth: Date;
}

export interface DoctorRegisterRequest extends RegisterRequest {
  licenseNumber: string;
  biography?: string;
  hospital?: string;
  clinic?: string;
  consultationFee: number;
  experienceYears: number;
  startTime: string;
  endTime: string;
  specializationId: number;
}








