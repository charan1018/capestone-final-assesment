import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { User } from '../../../core/models/user.model';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
      <div class="container">
        <a class="navbar-brand fw-bold" routerLink="/home">
          <i class="fas fa-heartbeat me-2"></i>
          Fracto
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav me-auto">
            <li class="nav-item">
              <a class="nav-link" routerLink="/home" routerLinkActive="active">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" routerLink="/doctors" routerLinkActive="active">Find Doctors</a>
            </li>
            <li class="nav-item" *ngIf="authService.isAuthenticated">
              <a class="nav-link" routerLink="/appointments" routerLinkActive="active">My Appointments</a>
            </li>
            <li class="nav-item" *ngIf="authService.isAdmin">
              <a class="nav-link" routerLink="/admin" routerLinkActive="active">Admin Panel</a>
            </li>
          </ul>

          <ul class="navbar-nav ms-auto">
            <ng-container *ngIf="!authService.isAuthenticated; else authenticatedUser">
              <li class="nav-item">
                <a class="nav-link" routerLink="/auth/login">Login</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/auth/register">Register</a>
              </li>
            </ng-container>

            <ng-template #authenticatedUser>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                  <i class="fas fa-user-circle me-1"></i>
                  {{ currentUser?.firstName }}
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                  <li><a class="dropdown-item" routerLink="/profile">Profile</a></li>
                  <li><hr class="dropdown-divider"></li>
                  <li><a class="dropdown-item" href="#" (click)="logout()">Logout</a></li>
                </ul>
              </li>
            </ng-template>
          </ul>
        </div>
      </div>
    </nav>
  `,
  styles: [`
    .navbar-brand {
      font-size: 1.5rem;
    }
    
    .navbar-nav .nav-link {
      font-weight: 500;
    }
    
    .navbar-nav .nav-link.active {
      color: #fff !important;
      font-weight: 600;
    }
    
    .dropdown-menu {
      border: none;
      box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }
  `]
})
export class HeaderComponent {
  currentUser: User | null = null;

  constructor(
    public authService: AuthService,
    private router: Router
  ) {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/home']);
  }
}








