import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container-fluid mt-4">
      <div class="row">
        <div class="col-12">
          <h2 class="mb-4">Admin Panel</h2>
          
          <div *ngIf="loading" class="text-center">
            <div class="spinner-border" role="status">
              <span class="visually-hidden">Loading...</span>
            </div>
          </div>

          <div *ngIf="error" class="alert alert-danger">
            <h4>Access Denied</h4>
            <p>{{ error }}</p>
          </div>

          <div *ngIf="!loading && !error">
            <div class="row">
              <div class="col-md-4 mb-4">
                <div class="card bg-primary text-white">
                  <div class="card-body">
                    <h4>{{ stats.totalDoctors }}</h4>
                    <p class="mb-0">Total Doctors</p>
                  </div>
                </div>
              </div>
              
              <div class="col-md-4 mb-4">
                <div class="card bg-success text-white">
                  <div class="card-body">
                    <h4>{{ stats.totalAppointments }}</h4>
                    <p class="mb-0">Total Appointments</p>
                  </div>
                </div>
              </div>
              
              <div class="col-md-4 mb-4">
                <div class="card bg-warning text-dark">
                  <div class="card-body">
                    <h4>{{ stats.pendingAppointments }}</h4>
                    <p class="mb-0">Pending Appointments</p>
                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-12">
                <h3>Doctors</h3>
                <div class="table-responsive">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Specialization</th>
                        <th>Experience</th>
                        <th>Fee</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr *ngFor="let doctor of doctors">
                        <td>{{ doctor.firstName }} {{ doctor.lastName }}</td>
                        <td>{{ doctor.email }}</td>
                        <td>{{ doctor.specialization }}</td>
                        <td>{{ doctor.experienceYears }} years</td>
                        <td>{{ doctor.consultationFee | currency }}</td>
                        <td>
                          <span class="badge" [ngClass]="doctor.isAvailable ? 'bg-success' : 'bg-danger'">
                            {{ doctor.isAvailable ? 'Available' : 'Unavailable' }}
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div class="row mt-4">
              <div class="col-12">
                <h3>Appointments</h3>
                <div class="table-responsive">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Patient ID</th>
                        <th>Doctor ID</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr *ngFor="let appointment of appointments">
                        <td>{{ appointment.id }}</td>
                        <td>{{ appointment.patientId }}</td>
                        <td>{{ appointment.doctorId }}</td>
                        <td>{{ formatDate(appointment.appointmentDate) }}</td>
                        <td>{{ formatTime(appointment.appointmentTime) }}</td>
                        <td>
                          <span class="badge" [ngClass]="getStatusClass(appointment.status)">
                            {{ getStatusText(appointment.status) }}
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      transition: transform 0.2s ease-in-out;
    }
    .card:hover {
      transform: translateY(-2px);
    }
  `]
})
export class AdminComponent implements OnInit {
  doctors: any[] = [];
  appointments: any[] = [];
  loading = false;
  error: string | null = null;
  
  stats = {
    totalDoctors: 0,
    totalAppointments: 0,
    pendingAppointments: 0
  };

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.loadAdminData();
  }

  loadAdminData() {
    this.loading = true;
    this.error = null;

    const token = localStorage.getItem('token');
    if (!token) {
      this.error = 'Please login to access admin panel';
      this.loading = false;
      return;
    }

    this.loadDoctors(token);
    this.loadAppointments(token);
  }

  loadDoctors(token: string) {
    this.http.get<any>(`${environment.apiUrl}/doctor`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    }).subscribe({
      next: (response) => {
        this.doctors = response.doctors || [];
        this.stats.totalDoctors = this.doctors.length;
      },
      error: (error) => {
        console.error('Error loading doctors:', error);
      }
    });
  }

  loadAppointments(token: string) {
    this.http.get<any[]>(`${environment.apiUrl}/appointment`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    }).subscribe({
      next: (appointments) => {
        this.appointments = appointments;
        this.stats.totalAppointments = appointments.length;
        this.stats.pendingAppointments = appointments.filter(a => a.status === 0).length;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading appointments:', error);
        if (error.status === 403) {
          this.error = 'Access denied. Admin privileges required.';
        } else {
          this.error = 'Failed to load admin data. Please try again.';
        }
        this.loading = false;
      }
    });
  }

  getStatusClass(status: number): string {
    switch (status) {
      case 0: return 'bg-warning text-dark';
      case 1: return 'bg-success text-white';
      case 2: return 'bg-info text-white';
      case 3: return 'bg-danger text-white';
      default: return 'bg-secondary text-white';
    }
  }

  getStatusText(status: number): string {
    switch (status) {
      case 0: return 'Pending';
      case 1: return 'Confirmed';
      case 2: return 'Completed';
      case 3: return 'Cancelled';
      default: return 'Unknown';
    }
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  formatTime(timeString: string): string {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
  }
}


