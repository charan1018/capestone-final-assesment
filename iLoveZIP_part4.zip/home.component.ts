import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <!-- Hero Section -->
    <section class="hero-section text-center text-white py-5">
      <div class="container">
        <div class="row align-items-center min-vh-100">
          <div class="col-lg-8 mx-auto">
            <h1 class="display-4 fw-bold mb-4">
              Your Health, Our Priority
            </h1>
            <p class="lead mb-5">
              Book appointments with top healthcare professionals easily and securely. 
              Get the care you deserve with Fracto's comprehensive doctor booking platform.
            </p>
            <div class="d-flex gap-3 justify-content-center flex-wrap">
              <a routerLink="/doctors" class="btn btn-primary btn-lg px-4">
                <i class="fas fa-search me-2"></i>Find Doctors
              </a>
              <a routerLink="/auth/register" class="btn btn-outline-light btn-lg px-4">
                <i class="fas fa-user-plus me-2"></i>Get Started
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section class="py-5">
      <div class="container">
        <div class="row text-center mb-5">
          <div class="col-lg-8 mx-auto">
            <h2 class="display-5 fw-bold mb-3">Why Choose Fracto?</h2>
            <p class="lead text-muted">
              We make healthcare accessible, convenient, and reliable for everyone.
            </p>
          </div>
        </div>
        
        <div class="row g-4">
          <div class="col-md-4">
            <div class="feature-card text-center p-4 h-100">
              <div class="feature-icon mb-3">
                <i class="fas fa-user-md fa-3x text-primary"></i>
              </div>
              <h4 class="mb-3">Expert Doctors</h4>
              <p class="text-muted">
                Connect with qualified healthcare professionals across various specializations.
              </p>
            </div>
          </div>
          
          <div class="col-md-4">
            <div class="feature-card text-center p-4 h-100">
              <div class="feature-icon mb-3">
                <i class="fas fa-clock fa-3x text-primary"></i>
              </div>
              <h4 class="mb-3">24/7 Booking</h4>
              <p class="text-muted">
                Book appointments anytime, anywhere with our user-friendly platform.
              </p>
            </div>
          </div>
          
          <div class="col-md-4">
            <div class="feature-card text-center p-4 h-100">
              <div class="feature-icon mb-3">
                <i class="fas fa-shield-alt fa-3x text-primary"></i>
              </div>
              <h4 class="mb-3">Secure & Private</h4>
              <p class="text-muted">
                Your health information is protected with industry-standard security measures.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- How It Works Section -->
    <section class="bg-light py-5">
      <div class="container">
        <div class="row text-center mb-5">
          <div class="col-lg-8 mx-auto">
            <h2 class="display-5 fw-bold mb-3">How It Works</h2>
            <p class="lead text-muted">
              Getting started with Fracto is simple and straightforward.
            </p>
          </div>
        </div>
        
        <div class="row g-4">
          <div class="col-md-3 text-center">
            <div class="step-number mb-3">1</div>
            <h5>Search Doctors</h5>
            <p class="text-muted">Find doctors by specialization, location, or availability.</p>
          </div>
          
          <div class="col-md-3 text-center">
            <div class="step-number mb-3">2</div>
            <h5>Choose Time Slot</h5>
            <p class="text-muted">Select from available appointment times that work for you.</p>
          </div>
          
          <div class="col-md-3 text-center">
            <div class="step-number mb-3">3</div>
            <h5>Book Appointment</h5>
            <p class="text-muted">Confirm your appointment with just a few clicks.</p>
          </div>
          
          <div class="col-md-3 text-center">
            <div class="step-number mb-3">4</div>
            <h5>Get Care</h5>
            <p class="text-muted">Attend your appointment and receive quality healthcare.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="py-5 bg-primary text-white">
      <div class="container text-center">
        <h2 class="display-5 fw-bold mb-3">Ready to Get Started?</h2>
        <p class="lead mb-4">
          Join thousands of patients who trust Fracto for their healthcare needs.
        </p>
        <a routerLink="/auth/register" class="btn btn-light btn-lg px-4">
          <i class="fas fa-rocket me-2"></i>Start Your Journey
        </a>
      </div>
    </section>
  `,
  styles: [`
    .hero-section {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
    }
    
    .feature-card {
      background: white;
      border-radius: 10px;
      box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .feature-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }
    
    .feature-icon {
      color: #007bff;
    }
    
    .step-number {
      width: 60px;
      height: 60px;
      background: #007bff;
      color: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      font-weight: bold;
      margin: 0 auto;
    }
    
    .btn-primary {
      background: #007bff;
      border-color: #007bff;
    }
    
    .btn-primary:hover {
      background: #0056b3;
      border-color: #0056b3;
    }
  `]
})
export class HomeComponent {}








