import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

interface DoctorDto {
  id: string;
  firstName: string;
  lastName: string;
  city?: string;
  profileImagePath?: string;
  specialization?: { id: number; name: string };
  consultationFee?: number;
  averageRating?: number;
}

interface DoctorSearchResultDto {
  doctors: DoctorDto[];
  totalCount: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

@Component({
  selector: 'app-doctors',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <section class="container py-4">
      <h2 class="mb-3">Doctors</h2>
      <div *ngIf="loading" class="text-muted">Loading...</div>
      <div *ngIf="!loading && doctors.length === 0" class="text-muted">No doctors found.</div>
      <div class="row g-3">
        <div class="col-md-4" *ngFor="let d of doctors">
          <div class="card h-100">
            <img *ngIf="d.profileImagePath" [src]="d.profileImagePath" class="card-img-top" alt="Doctor photo" />
            <div class="card-body">
              <h5 class="card-title">{{ d.firstName }} {{ d.lastName }}</h5>
              <p class="card-text mb-1" *ngIf="d.specialization">{{ d.specialization.name }}</p>
              <p class="card-text mb-1" *ngIf="d.city">{{ d.city }}</p>
              <p class="card-text mb-1" *ngIf="d.consultationFee">Fee: {{ d.consultationFee | currency }}</p>
              <p class="card-text mb-3" *ngIf="d.averageRating !== undefined">Rating: {{ d.averageRating | number:'1.1-1' }}</p>
              <a routerLink="/booking" class="btn btn-primary btn-sm">Book Appointment</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
})
export class DoctorsComponent implements OnInit {
  private http = inject(HttpClient);
  doctors: DoctorDto[] = [];
  loading = false;

  ngOnInit(): void {
    this.fetchDoctors();
  }

  private fetchDoctors(): void {
    this.loading = true;
    const url = `${environment.apiUrl}/doctor?page=1&pageSize=50`;
    this.http.get<DoctorSearchResultDto>(url).subscribe({
      next: (res) => {
        this.doctors = res.doctors ?? [];
        this.loading = false;
      },
      error: (error) => {
        console.error('Error fetching doctors:', error);
        this.loading = false;
      }
    });
  }
}




