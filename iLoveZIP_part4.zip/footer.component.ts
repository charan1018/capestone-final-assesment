import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule],
  template: `
    <footer class="bg-dark text-light py-4 mt-auto">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <h5 class="mb-3">
              <i class="fas fa-heartbeat me-2 text-primary"></i>
              Fracto
            </h5>
            <p class="text-muted">
              Your trusted platform for doctor appointments. 
              Connect with healthcare professionals easily and securely.
            </p>
          </div>
          <div class="col-md-3">
            <h6 class="mb-3">Quick Links</h6>
            <ul class="list-unstyled">
              <li><a href="/home" class="text-muted text-decoration-none">Home</a></li>
              <li><a href="/doctors" class="text-muted text-decoration-none">Find Doctors</a></li>
              <li><a href="/about" class="text-muted text-decoration-none">About Us</a></li>
              <li><a href="/contact" class="text-muted text-decoration-none">Contact</a></li>
            </ul>
          </div>
          <div class="col-md-3">
            <h6 class="mb-3">Contact Info</h6>
            <ul class="list-unstyled text-muted">
              <li><i class="fas fa-phone me-2"></i>+1 (555) 123-4567</li>
              <li><i class="fas fa-envelope me-2"></i>info&#64;fracto.com</li>
              <li><i class="fas fa-map-marker-alt me-2"></i>123 Health St, Medical City</li>
            </ul>
          </div>
        </div>
        <hr class="my-4">
        <div class="row align-items-center">
          <div class="col-md-6">
            <p class="mb-0 text-muted">
              &copy; 2024 Fracto. All rights reserved.
            </p>
          </div>
          <div class="col-md-6 text-md-end">
            <div class="social-links">
              <a href="#" class="text-muted me-3"><i class="fab fa-facebook-f"></i></a>
              <a href="#" class="text-muted me-3"><i class="fab fa-twitter"></i></a>
              <a href="#" class="text-muted me-3"><i class="fab fa-linkedin-in"></i></a>
              <a href="#" class="text-muted"><i class="fab fa-instagram"></i></a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  `,
  styles: [`
    footer {
      margin-top: auto;
    }
    
    .social-links a {
      font-size: 1.2rem;
      transition: color 0.3s ease;
    }
    
    .social-links a:hover {
      color: #fff !important;
    }
    
    .text-primary {
      color: #007bff !important;
    }
  `]
})
export class FooterComponent {}







