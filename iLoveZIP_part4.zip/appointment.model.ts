export interface Appointment {
  id: number;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  specializationName: string;
  appointmentDate: Date;
  appointmentTime: string;
  symptoms?: string;
  notes?: string;
  status: AppointmentStatus;
  createdAt: Date;
  updatedAt?: Date;
  cancelledAt?: Date;
  cancellationReason?: string;
  consultationFee: number;
}

export enum AppointmentStatus {
  Pending = 0,
  Confirmed = 1,
  Completed = 2,
  Cancelled = 3,
  NoShow = 4
}

export interface CreateAppointmentRequest {
  doctorId: number;
  timeSlotId: number;
  appointmentDate: Date;
  appointmentTime: string;
  symptoms?: string;
  notes?: string;
}

export interface UpdateAppointmentRequest {
  symptoms?: string;
  notes?: string;
  status?: AppointmentStatus;
  cancellationReason?: string;
}

export interface AppointmentSearchRequest {
  patientId?: string;
  doctorId?: string;
  status?: AppointmentStatus;
  fromDate?: Date;
  toDate?: Date;
  page: number;
  pageSize: number;
}

export interface AppointmentSearchResult {
  appointments: Appointment[];
  totalCount: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export interface TimeSlot {
  id: number;
  date: Date;
  startTime: string;
  endTime: string;
  isAvailable: boolean;
  isBooked: boolean;
}

export interface AvailableTimeSlots {
  doctorId: number;
  doctorName: string;
  date: Date;
  timeSlots: TimeSlot[];
}








