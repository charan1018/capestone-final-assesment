import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

interface Doctor {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  specialization: string;
  consultationFee: number;
  experienceYears: number;
  isAvailable: boolean;
  hospital: string;
  clinic: string;
}

interface TimeSlot {
  id: number;
  doctorId: string;
  date: string;
  startTime: string;
  endTime: string;
  isAvailable: boolean;
  isBooked: boolean;
}

@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-4">
      <div class="row">
        <div class="col-12">
          <h2 class="mb-4">Book Appointment</h2>
          
          <div *ngIf="loading" class="text-center">
            <div class="spinner-border" role="status">
              <span class="visually-hidden">Loading...</span>
            </div>
          </div>

          <div *ngIf="error" class="alert alert-danger">
            <h4>Error</h4>
            <p>{{ error }}</p>
          </div>

          <div *ngIf="success" class="alert alert-success">
            <h4>Success!</h4>
            <p>{{ success }}</p>
          </div>

          <div *ngIf="!loading && !error && !success" class="row">
            <!-- Doctor Selection -->
            <div class="col-md-6 mb-4">
              <div class="card">
                <div class="card-header">
                  <h5>Select Doctor</h5>
                </div>
                <div class="card-body">
                  <div class="mb-3">
                    <label for="doctorSelect" class="form-label">Choose a Doctor:</label>
                    <select id="doctorSelect" class="form-select" [(ngModel)]="selectedDoctorId" (change)="onDoctorChange()">
                      <option value="">Select a doctor...</option>
                      <option *ngFor="let doctor of doctors" [value]="doctor.id">
                        {{ doctor.firstName }} {{ doctor.lastName }} - {{ doctor.specialization }}
                      </option>
                    </select>
                  </div>
                  
                  <div *ngIf="selectedDoctor" class="doctor-info">
                    <h6>{{ selectedDoctor.firstName }} {{ selectedDoctor.lastName }}</h6>
                    <p class="text-muted">{{ selectedDoctor.specialization }}</p>
                    <p><strong>Experience:</strong> {{ selectedDoctor.experienceYears }} years</p>
                    <p><strong>Fee:</strong> {{ selectedDoctor.consultationFee | currency }}</p>
                    <p><strong>Hospital:</strong> {{ selectedDoctor.hospital }}</p>
                    <p><strong>Clinic:</strong> {{ selectedDoctor.clinic }}</p>
                  </div>
                </div>
              </div>
            </div>

            <!-- Time Slot Selection -->
            <div class="col-md-6 mb-4">
              <div class="card">
                <div class="card-header">
                  <h5>Select Time Slot</h5>
                </div>
                <div class="card-body">
                  <div *ngIf="!selectedDoctorId" class="text-muted">
                    Please select a doctor first
                  </div>
                  
                  <div *ngIf="selectedDoctorId && timeSlots.length === 0" class="text-muted">
                    No available time slots for this doctor
                  </div>
                  
                  <div *ngIf="selectedDoctorId && timeSlots.length > 0">
                    <div class="mb-3">
                      <label for="dateSelect" class="form-label">Select Date:</label>
                      <select id="dateSelect" class="form-select" [(ngModel)]="selectedDate" (change)="onDateChange()">
                        <option value="">Select a date...</option>
                        <option *ngFor="let date of availableDates" [value]="date">
                          {{ formatDate(date) }}
                        </option>
                      </select>
                    </div>
                    
                    <div *ngIf="selectedDate && availableTimeSlots.length > 0">
                      <label class="form-label">Available Time Slots:</label>
                      <div class="row">
                        <div *ngFor="let slot of availableTimeSlots" class="col-md-6 mb-2">
                          <div class="form-check">
                            <input 
                              class="form-check-input" 
                              type="radio" 
                              name="timeSlot" 
                              [id]="'slot-' + slot.id"
                              [value]="slot.id"
                              [(ngModel)]="selectedTimeSlotId"
                              [disabled]="!slot.isAvailable || slot.isBooked">
                            <label class="form-check-label" [for]="'slot-' + slot.id">
                              {{ formatTime(slot.startTime) }} - {{ formatTime(slot.endTime) }}
                              <span *ngIf="slot.isBooked" class="badge bg-danger ms-2">Booked</span>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Appointment Details -->
            <div class="col-12 mb-4">
              <div class="card">
                <div class="card-header">
                  <h5>Appointment Details</h5>
                </div>
                <div class="card-body">
                  <form (ngSubmit)="bookAppointment()">
                    <div class="row">
                      <div class="col-md-6 mb-3">
                        <label for="symptoms" class="form-label">Symptoms/Reason for Visit:</label>
                        <textarea 
                          id="symptoms" 
                          class="form-control" 
                          rows="3" 
                          [(ngModel)]="appointmentData.symptoms" 
                          name="symptoms"
                          placeholder="Describe your symptoms or reason for the appointment..."
                          required></textarea>
                      </div>
                      
                      <div class="col-md-6 mb-3">
                        <label for="notes" class="form-label">Additional Notes:</label>
                        <textarea 
                          id="notes" 
                          class="form-control" 
                          rows="3" 
                          [(ngModel)]="appointmentData.notes" 
                          name="notes"
                          placeholder="Any additional information you'd like to share..."></textarea>
                      </div>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                      <button 
                        type="submit" 
                        class="btn btn-primary"
                        [disabled]="!canBookAppointment()">
                        Book Appointment
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .doctor-info {
      background-color: #f8f9fa;
      padding: 15px;
      border-radius: 5px;
      margin-top: 15px;
    }
    .card {
      transition: transform 0.2s ease-in-out;
    }
    .card:hover {
      transform: translateY(-2px);
    }
  `]
})
export class BookingComponent implements OnInit {
  doctors: Doctor[] = [];
  timeSlots: TimeSlot[] = [];
  selectedDoctorId: string = '';
  selectedDoctor: Doctor | null = null;
  selectedDate: string = '';
  selectedTimeSlotId: number | null = null;
  loading = false;
  error: string | null = null;
  success: string | null = null;

  appointmentData = {
    symptoms: '',
    notes: ''
  };

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.loadDoctors();
  }

  loadDoctors() {
    this.loading = true;
    this.http.get<any>(`${environment.apiUrl}/doctor?page=1&pageSize=50`).subscribe({
      next: (response) => {
        this.doctors = response.doctors || [];
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading doctors:', error);
        this.error = 'Failed to load doctors. Please try again.';
        this.loading = false;
      }
    });
  }

  onDoctorChange() {
    this.selectedDoctor = this.doctors.find(d => d.id === this.selectedDoctorId) || null;
    this.selectedDate = '';
    this.selectedTimeSlotId = null;
    this.timeSlots = [];
    
    if (this.selectedDoctorId) {
      this.loadTimeSlots();
    }
  }

  loadTimeSlots() {
    if (!this.selectedDoctorId) return;
    
    // Get time slots for the next 7 days
    const today = new Date();
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      dates.push(date.toISOString().split('T')[0]);
    }
    
    // Load time slots for each date
    this.timeSlots = [];
    dates.forEach(date => {
      this.http.get<any>(`${environment.apiUrl}/doctor/${this.selectedDoctorId}/time-slots?date=${date}`).subscribe({
        next: (response) => {
          if (response.timeSlots) {
            this.timeSlots.push(...response.timeSlots);
          }
        },
        error: (error) => {
          console.error('Error loading time slots:', error);
        }
      });
    });
    
    // If no time slots from API, generate sample ones
    if (this.timeSlots.length === 0) {
      this.generateSampleTimeSlots();
    }
  }

  generateSampleTimeSlots() {
    const today = new Date();
    const timeSlots: TimeSlot[] = [];
    
    // Generate time slots for the next 7 days
    for (let i = 0; i < 7; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      const dateStr = date.toISOString().split('T')[0];
      
      // Generate 3 time slots per day
      const times = ['09:00:00', '10:00:00', '11:00:00'];
      times.forEach((time, index) => {
        timeSlots.push({
          id: timeSlots.length + 1,
          doctorId: this.selectedDoctorId,
          date: dateStr,
          startTime: time,
          endTime: this.addHours(time, 1),
          isAvailable: true,
          isBooked: Math.random() < 0.3 // Randomly mark some as booked
        });
      });
    }
    
    this.timeSlots = timeSlots;
  }

  addHours(time: string, hours: number): string {
    const [h, m, s] = time.split(':').map(Number);
    const newHour = (h + hours) % 24;
    return `${newHour.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }

  onDateChange() {
    this.selectedTimeSlotId = null;
  }

  get availableDates(): string[] {
    const dates = [...new Set(this.timeSlots.map(slot => slot.date))];
    return dates.sort();
  }

  get availableTimeSlots(): TimeSlot[] {
    return this.timeSlots.filter(slot => 
      slot.date === this.selectedDate && 
      slot.isAvailable && 
      !slot.isBooked
    );
  }

  canBookAppointment(): boolean {
    return !!(
      this.selectedDoctorId &&
      this.selectedDate &&
      this.selectedTimeSlotId &&
      this.appointmentData.symptoms.trim()
    );
  }

  bookAppointment() {
    if (!this.canBookAppointment()) {
      this.error = 'Please fill in all required fields';
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      this.error = 'Please login to book an appointment';
      return;
    }

    const selectedSlot = this.timeSlots.find(slot => slot.id === this.selectedTimeSlotId);
    if (!selectedSlot) {
      this.error = 'Please select a valid time slot';
      return;
    }

    const appointmentPayload = {
      doctorId: this.selectedDoctorId,
      timeSlotId: this.selectedTimeSlotId,
      appointmentDate: this.selectedDate,
      appointmentTime: selectedSlot.startTime,
      symptoms: this.appointmentData.symptoms,
      notes: this.appointmentData.notes
    };

    this.loading = true;
    this.error = null;
    this.success = null;

    this.http.post<any>(`${environment.apiUrl}/appointment`, appointmentPayload, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    }).subscribe({
      next: (response) => {
        this.success = 'Appointment booked successfully!';
        this.loading = false;
        this.resetForm();
      },
      error: (error) => {
        console.error('Error booking appointment:', error);
        this.error = 'Failed to book appointment. Please try again.';
        this.loading = false;
      }
    });
  }

  resetForm() {
    this.selectedDoctorId = '';
    this.selectedDoctor = null;
    this.selectedDate = '';
    this.selectedTimeSlotId = null;
    this.timeSlots = [];
    this.appointmentData = {
      symptoms: '',
      notes: ''
    };
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  formatTime(timeString: string): string {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
  }
}

