import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="container py-5" style="max-width: 420px;">
      <h3 class="mb-3">Login</h3>
      <form (ngSubmit)="submit()" #f="ngForm">
        <div class="mb-3">
          <label class="form-label">Email</label>
          <input class="form-control" name="email" type="email" required [(ngModel)]="email" />
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input class="form-control" name="password" type="password" required [(ngModel)]="password" />
        </div>
        <button class="btn btn-primary w-100" [disabled]="loading">{{ loading ? 'Signing in...' : 'Login' }}</button>
      </form>
      <div class="mt-3">
        <a routerLink="/auth/register">Create an account</a>
      </div>
      <div *ngIf="error" class="alert alert-danger mt-3">{{ error }}</div>
    </div>
  `
})
export class LoginComponent {
  private auth = inject(AuthService);
  private router = inject(Router);

  email = '';
  password = '';
  loading = false;
  error = '';

  submit(): void {
    if (!this.email || !this.password) { return; }
    this.loading = true;
    this.error = '';
    this.auth.login({ email: this.email, password: this.password }).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigateByUrl('/');
      },
      error: (e) => {
        this.loading = false;
        this.error = e?.error?.message || 'Login failed';
      }
    });
  }
}






