import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="container py-5" style="max-width: 480px;">
      <h3 class="mb-3">Register</h3>
      <form (ngSubmit)="submit()" #f="ngForm">
        <div class="row g-2">
          <div class="col-md-6">
            <label class="form-label">First name</label>
            <input class="form-control" name="firstName" required [(ngModel)]="firstName" />
          </div>
          <div class="col-md-6">
            <label class="form-label">Last name</label>
            <input class="form-control" name="lastName" required [(ngModel)]="lastName" />
          </div>
        </div>
        <div class="mb-3 mt-2">
          <label class="form-label">Email</label>
          <input class="form-control" name="email" type="email" required [(ngModel)]="email" />
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input class="form-control" name="password" type="password" required [(ngModel)]="password" />
        </div>
        <div class="mb-3">
          <label class="form-label">Confirm password</label>
          <input class="form-control" name="confirmPassword" type="password" required [(ngModel)]="confirmPassword" />
        </div>
        <div class="row g-2">
          <div class="col-md-6">
            <label class="form-label">City</label>
            <input class="form-control" name="city" [(ngModel)]="city" />
          </div>
          <div class="col-md-6">
            <label class="form-label">Phone</label>
            <input class="form-control" name="phoneNumber" [(ngModel)]="phoneNumber" />
          </div>
        </div>
        <div class="mb-3 mt-2">
          <label class="form-label">Date of birth</label>
          <input class="form-control" name="dateOfBirth" type="date" required [(ngModel)]="dateOfBirth" />
        </div>
        <button class="btn btn-primary w-100" [disabled]="loading">{{ loading ? 'Creating...' : 'Register' }}</button>
      </form>
      <div class="mt-3">
        <a routerLink="/auth/login">Already have an account? Login</a>
      </div>
      <div *ngIf="error" class="alert alert-danger mt-3">{{ error }}</div>
    </div>
  `
})
export class RegisterComponent {
  private auth = inject(AuthService);
  private router = inject(Router);

  firstName = '';
  lastName = '';
  email = '';
  password = '';
  confirmPassword = '';
  city = '';
  phoneNumber = '';
  dateOfBirth = '';
  loading = false;
  error = '';

  submit(): void {
    if (this.password !== this.confirmPassword) {
      this.error = 'Passwords do not match';
      return;
    }
    this.loading = true;
    this.error = '';
    this.auth.register({
      firstName: this.firstName,
      lastName: this.lastName,
      email: this.email,
      password: this.password,
      confirmPassword: this.confirmPassword,
      city: this.city,
      phoneNumber: this.phoneNumber,
      dateOfBirth: new Date(this.dateOfBirth),
      address: ''
    }).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigateByUrl('/');
      },
      error: (e) => {
        this.loading = false;
        this.error = e?.error?.message || 'Registration failed';
      }
    });
  }
}






