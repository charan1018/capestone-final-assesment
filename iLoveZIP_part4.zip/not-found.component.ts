import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="container text-center py-5">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <h1 class="display-1 text-primary">404</h1>
          <h2 class="mb-4">Page Not Found</h2>
          <p class="lead mb-4">
            The page you are looking for doesn't exist or has been moved.
          </p>
          <a routerLink="/home" class="btn btn-primary btn-lg">
            <i class="fas fa-home me-2"></i>
            Go Home
          </a>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .display-1 {
      font-size: 8rem;
      font-weight: bold;
    }
  `]
})
export class NotFoundComponent {}
