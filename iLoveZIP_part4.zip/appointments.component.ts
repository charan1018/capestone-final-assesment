import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

interface Appointment {
  id: number;
  patientId: string;
  doctorId: string;
  appointmentDate: string;
  appointmentTime: string;
  symptoms: string;
  notes: string;
  status: number;
  createdAt: string;
  doctor?: {
    firstName: string;
    lastName: string;
    specialization: string;
  };
}

@Component({
  selector: 'app-appointments',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="container mt-4">
      <div class="row">
        <div class="col-12">
          <h2 class="mb-4">My Appointments</h2>
          
          <div *ngIf="loading" class="text-center">
            <div class="spinner-border" role="status">
              <span class="visually-hidden">Loading...</span>
            </div>
          </div>

          <div *ngIf="!loading && appointments.length === 0" class="alert alert-info">
            <h4>No Appointments Found</h4>
            <p>You don't have any appointments yet. <a routerLink="/doctors">Find a doctor</a> to book your first appointment!</p>
          </div>

          <div *ngIf="!loading && appointments.length > 0" class="row">
            <div *ngFor="let appointment of appointments" class="col-md-6 col-lg-4 mb-4">
              <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                  <h5 class="card-title mb-0">Appointment #{{ appointment.id }}</h5>
                  <span class="badge" [ngClass]="getStatusClass(appointment.status)">
                    {{ getStatusText(appointment.status) }}
                  </span>
                </div>
                <div class="card-body">
                  <div *ngIf="appointment.doctor" class="mb-3">
                    <h6 class="text-primary">{{ appointment.doctor.firstName }} {{ appointment.doctor.lastName }}</h6>
                    <small class="text-muted">{{ appointment.doctor.specialization }}</small>
                  </div>
                  <div class="mb-2">
                    <strong>Date:</strong> {{ formatDate(appointment.appointmentDate) }}
                  </div>
                  <div class="mb-2">
                    <strong>Time:</strong> {{ formatTime(appointment.appointmentTime) }}
                  </div>
                  <div *ngIf="appointment.symptoms" class="mb-2">
                    <strong>Symptoms:</strong> {{ appointment.symptoms }}
                  </div>
                  <div *ngIf="appointment.notes" class="mb-2">
                    <strong>Notes:</strong> {{ appointment.notes }}
                  </div>
                </div>
                <div class="card-footer">
                  <small class="text-muted">
                    Created: {{ formatDateTime(appointment.createdAt) }}
                  </small>
                </div>
              </div>
            </div>
          </div>

          <div *ngIf="error" class="alert alert-danger">
            <h4>Error Loading Appointments</h4>
            <p>{{ error }}</p>
            <button class="btn btn-outline-danger" (click)="loadAppointments()">Try Again</button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      transition: transform 0.2s ease-in-out;
    }
    .card:hover {
      transform: translateY(-2px);
    }
    .badge {
      font-size: 0.75rem;
    }
  `]
})
export class AppointmentsComponent implements OnInit {
  appointments: Appointment[] = [];
  loading = false;
  error: string | null = null;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.loadAppointments();
  }

  loadAppointments() {
    this.loading = true;
    this.error = null;

    // Get token from localStorage
    const token = localStorage.getItem('token');
    if (!token) {
      this.error = 'Please login to view your appointments';
      this.loading = false;
      return;
    }

    this.http.get<Appointment[]>(`${environment.apiUrl}/appointment`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    }).subscribe({
      next: (appointments) => {
        this.appointments = appointments;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading appointments:', error);
        this.error = 'Failed to load appointments. Please try again.';
        this.loading = false;
      }
    });
  }

  getStatusClass(status: number): string {
    switch (status) {
      case 0: return 'bg-warning text-dark';
      case 1: return 'bg-success text-white';
      case 2: return 'bg-info text-white';
      case 3: return 'bg-danger text-white';
      default: return 'bg-secondary text-white';
    }
  }

  getStatusText(status: number): string {
    switch (status) {
      case 0: return 'Pending';
      case 1: return 'Confirmed';
      case 2: return 'Completed';
      case 3: return 'Cancelled';
      default: return 'Unknown';
    }
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  formatTime(timeString: string): string {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
  }

  formatDateTime(dateString: string): string {
    return new Date(dateString).toLocaleString();
  }
}
