import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { User, AuthResponse, LoginRequest, RegisterRequest, DoctorRegisterRequest } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly apiUrl = `${environment.apiUrl}/auth`;
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(private http: HttpClient) {
    this.loadStoredUser();
  }

  get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  get isAuthenticated(): boolean {
    return !!this.currentUserValue && !!this.getToken();
  }

  get isAdmin(): boolean {
    return this.currentUserValue?.roles.includes('Admin') ?? false;
  }

  get isDoctor(): boolean {
    return this.currentUserValue?.roles.includes('Doctor') ?? false;
  }

  get isUser(): boolean {
    return this.currentUserValue?.roles.includes('User') ?? false;
  }

  login(credentials: LoginRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/login`, credentials)
      .pipe(
        tap(response => {
          if (response.isSuccess && response.token && response.user) {
            this.setToken(response.token);
            this.setCurrentUser(response.user);
          }
        })
      );
  }

  register(userData: RegisterRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/register`, userData)
      .pipe(
        tap(response => {
          if (response.isSuccess && response.token && response.user) {
            this.setToken(response.token);
            this.setCurrentUser(response.user);
          }
        })
      );
  }

  registerDoctor(doctorData: DoctorRegisterRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/register-doctor`, doctorData)
      .pipe(
        tap(response => {
          if (response.isSuccess && response.token && response.user) {
            this.setToken(response.token);
            this.setCurrentUser(response.user);
          }
        })
      );
  }

  logout(): void {
    this.removeToken();
    this.currentUserSubject.next(null);
  }

  getProfile(): Observable<User> {
    return this.http.get<User>(`${this.apiUrl}/profile`);
  }

  refreshUserData(): void {
    if (this.isAuthenticated) {
      this.getProfile().subscribe({
        next: (user) => this.setCurrentUser(user),
        error: () => this.logout()
      });
    }
  }

  private setCurrentUser(user: User): void {
    this.currentUserSubject.next(user);
    localStorage.setItem('currentUser', JSON.stringify(user));
  }

  private loadStoredUser(): void {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser);
        this.currentUserSubject.next(user);
      } catch {
        localStorage.removeItem('currentUser');
      }
    }
  }

  private setToken(token: string): void {
    localStorage.setItem('authToken', token);
  }

  private getToken(): string | null {
    return localStorage.getItem('authToken');
  }

  private removeToken(): void {
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');
  }

  getAuthHeaders(): { [key: string]: string } {
    const token = this.getToken();
    return token ? { Authorization: `Bearer ${token}` } : {};
  }
}








