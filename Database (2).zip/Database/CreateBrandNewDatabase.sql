-- =============================================
-- CREATE BRAND NEW DATABASE WITH COMPLETE CRUD OPERATIONS
-- =============================================

USE master;
GO

-- Create brand new database
CREATE DATABASE FractoAppointmentSystem;
GO

USE FractoAppointmentSystem;
GO

PRINT '=============================================';
PRINT 'CREATING BRAND NEW FRACTO APPOINTMENT SYSTEM';
PRINT 'Database: FractoAppointmentSystem';
PRINT '=============================================';
PRINT '';

-- =============================================
-- CREATE TABLES
-- =============================================

-- Create Specializations table
CREATE TABLE Specializations (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500),
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

-- Create Users table (for Identity)
CREATE TABLE Users (
    Id NVARCHAR(450) PRIMARY KEY,
    UserName NVARCHAR(256),
    NormalizedUserName NVARCHAR(256),
    Email NVARCHAR(256),
    NormalizedEmail NVARCHAR(256),
    EmailConfirmed BIT NOT NULL DEFAULT 0,
    PasswordHash NVARCHAR(MAX),
    SecurityStamp NVARCHAR(MAX),
    ConcurrencyStamp NVARCHAR(MAX),
    PhoneNumber NVARCHAR(MAX),
    PhoneNumberConfirmed BIT NOT NULL DEFAULT 0,
    TwoFactorEnabled BIT NOT NULL DEFAULT 0,
    LockoutEnd DATETIME2,
    LockoutEnabled BIT NOT NULL DEFAULT 1,
    AccessFailedCount INT NOT NULL DEFAULT 0,
    FirstName NVARCHAR(100) NOT NULL,
    LastName NVARCHAR(100) NOT NULL,
    Address NVARCHAR(200),
    City NVARCHAR(50),
    ProfileImagePath NVARCHAR(500),
    DateOfBirth DATE,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2,
    IsActive BIT NOT NULL DEFAULT 1
);
GO

-- Create Doctors table
CREATE TABLE Doctors (
    Id NVARCHAR(450) PRIMARY KEY,
    LicenseNumber NVARCHAR(100) NOT NULL,
    Biography NVARCHAR(1000),
    Hospital NVARCHAR(200),
    Clinic NVARCHAR(200),
    ConsultationFee DECIMAL(18,2) NOT NULL,
    ExperienceYears INT NOT NULL,
    IsAvailable BIT NOT NULL DEFAULT 1,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    SpecializationId INT NOT NULL,
    FOREIGN KEY (Id) REFERENCES Users(Id) ON DELETE CASCADE,
    FOREIGN KEY (SpecializationId) REFERENCES Specializations(Id)
);
GO

-- Create TimeSlots table
CREATE TABLE TimeSlots (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    DoctorId NVARCHAR(450) NOT NULL,
    Date DATE NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    IsAvailable BIT NOT NULL DEFAULT 1,
    IsBooked BIT NOT NULL DEFAULT 0,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    FOREIGN KEY (DoctorId) REFERENCES Doctors(Id) ON DELETE CASCADE
);
GO

-- Create Appointments table
CREATE TABLE Appointments (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    PatientId NVARCHAR(450) NOT NULL,
    DoctorId NVARCHAR(450) NOT NULL,
    TimeSlotId INT,
    AppointmentDate DATE NOT NULL,
    AppointmentTime TIME NOT NULL,
    Symptoms NVARCHAR(500),
    Notes NVARCHAR(500),
    Status INT NOT NULL DEFAULT 0, -- 0=Pending, 1=Confirmed, 2=Completed, 3=Cancelled
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2,
    CancelledAt DATETIME2,
    CancellationReason NVARCHAR(200),
    FOREIGN KEY (PatientId) REFERENCES Users(Id),
    FOREIGN KEY (DoctorId) REFERENCES Doctors(Id),
    FOREIGN KEY (TimeSlotId) REFERENCES TimeSlots(Id)
);
GO

-- Create Ratings table
CREATE TABLE Ratings (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    PatientId NVARCHAR(450) NOT NULL,
    DoctorId NVARCHAR(450) NOT NULL,
    AppointmentId INT,
    RatingValue INT NOT NULL CHECK (RatingValue >= 1 AND RatingValue <= 5),
    Review NVARCHAR(1000),
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    FOREIGN KEY (PatientId) REFERENCES Users(Id),
    FOREIGN KEY (DoctorId) REFERENCES Doctors(Id),
    FOREIGN KEY (AppointmentId) REFERENCES Appointments(Id)
);
GO

-- Create Identity tables
CREATE TABLE AspNetRoles (
    Id NVARCHAR(450) NOT NULL PRIMARY KEY,
    Name NVARCHAR(256),
    NormalizedName NVARCHAR(256),
    ConcurrencyStamp NVARCHAR(MAX)
);
GO

CREATE TABLE AspNetUserRoles (
    UserId NVARCHAR(450) NOT NULL,
    RoleId NVARCHAR(450) NOT NULL,
    PRIMARY KEY (UserId, RoleId),
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
    FOREIGN KEY (RoleId) REFERENCES AspNetRoles(Id) ON DELETE CASCADE
);
GO

PRINT '✓ All tables created successfully';
PRINT '';

-- =============================================
-- INSERT INITIAL DATA
-- =============================================

-- Insert Specializations
INSERT INTO Specializations (Name, Description, IsActive, CreatedAt) VALUES
('Cardiology', 'Heart and cardiovascular system treatment', 1, GETUTCDATE()),
('Dermatology', 'Skin, hair, and nails treatment', 1, GETUTCDATE()),
('Neurology', 'Nervous system and brain treatment', 1, GETUTCDATE()),
('Orthopedics', 'Bones, joints, and muscles treatment', 1, GETUTCDATE()),
('Pediatrics', 'Children''s health and development', 1, GETUTCDATE()),
('Psychiatry', 'Mental health and behavioral disorders', 1, GETUTCDATE()),
('General Medicine', 'General health and wellness', 1, GETUTCDATE()),
('Gynecology', 'Women''s health and reproductive system', 1, GETUTCDATE()),
('Ophthalmology', 'Eye and vision care', 1, GETUTCDATE()),
('ENT', 'Ear, nose, and throat treatment', 1, GETUTCDATE()),
('Oncology', 'Cancer treatment and care', 1, GETUTCDATE()),
('Urology', 'Urinary tract and male reproductive system', 1, GETUTCDATE()),
('Radiology', 'Medical imaging and diagnostic radiology', 1, GETUTCDATE()),
('Anesthesiology', 'Pain management and surgical anesthesia', 1, GETUTCDATE()),
('Emergency Medicine', 'Emergency and critical care', 1, GETUTCDATE());
GO

-- Insert Roles
INSERT INTO AspNetRoles (Id, Name, NormalizedName, ConcurrencyStamp) VALUES
('role-admin-001', 'Admin', 'ADMIN', NEWID()),
('role-doctor-001', 'Doctor', 'DOCTOR', NEWID()),
('role-user-001', 'User', 'USER', NEWID());
GO

-- Insert Admin User
INSERT INTO Users (Id, UserName, NormalizedUserName, Email, NormalizedEmail, EmailConfirmed, PasswordHash, SecurityStamp, ConcurrencyStamp, FirstName, LastName, City, Address, PhoneNumber, CreatedAt, IsActive) VALUES
('admin-001', 'admin@fracto.com', 'ADMIN@FRACTO.COM', 'admin@fracto.com', 'ADMIN@FRACTO.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp1', 'ConcurrencyStamp1', 'System', 'Administrator', 'Metropolis', '123 Admin Street', '+1-555-0001', GETUTCDATE(), 1);
GO

-- Insert Doctor Users
INSERT INTO Users (Id, UserName, NormalizedUserName, Email, NormalizedEmail, EmailConfirmed, PasswordHash, SecurityStamp, ConcurrencyStamp, FirstName, LastName, City, Address, PhoneNumber, CreatedAt, IsActive) VALUES
('doctor-001', 'dr.smith@fracto.com', 'DR.SMITH@FRACTO.COM', 'dr.smith@fracto.com', 'DR.SMITH@FRACTO.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp2', 'ConcurrencyStamp2', 'Dr. John', 'Smith', 'Metropolis', '456 Medical Center', '+1-555-0101', GETUTCDATE(), 1),
('doctor-002', 'dr.johnson@fracto.com', 'DR.JOHNSON@FRACTO.COM', 'dr.johnson@fracto.com', 'DR.JOHNSON@FRACTO.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp3', 'ConcurrencyStamp3', 'Dr. Sarah', 'Johnson', 'Metropolis', '789 Health Plaza', '+1-555-0102', GETUTCDATE(), 1),
('doctor-003', 'dr.williams@fracto.com', 'DR.WILLIAMS@FRACTO.COM', 'dr.williams@fracto.com', 'DR.WILLIAMS@FRACTO.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp4', 'ConcurrencyStamp4', 'Dr. Michael', 'Williams', 'Metropolis', '321 Care Avenue', '+1-555-0103', GETUTCDATE(), 1),
('doctor-004', 'dr.brown@fracto.com', 'DR.BROWN@FRACTO.COM', 'dr.brown@fracto.com', 'DR.BROWN@FRACTO.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp5', 'ConcurrencyStamp5', 'Dr. Emily', 'Brown', 'Metropolis', '654 Wellness Blvd', '+1-555-0104', GETUTCDATE(), 1),
('doctor-005', 'dr.davis@fracto.com', 'DR.DAVIS@FRACTO.COM', 'dr.davis@fracto.com', 'DR.DAVIS@FRACTO.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp6', 'ConcurrencyStamp6', 'Dr. David', 'Davis', 'Metropolis', '987 Medical Drive', '+1-555-0105', GETUTCDATE(), 1),
('doctor-006', 'dr.taylor@fracto.com', 'DR.TAYLOR@FRACTO.COM', 'dr.taylor@fracto.com', 'DR.TAYLOR@FRACTO.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp7', 'ConcurrencyStamp7', 'Dr. Jennifer', 'Taylor', 'Metropolis', '111 Cancer Center', '+1-555-0106', GETUTCDATE(), 1),
('doctor-007', 'dr.wilson@fracto.com', 'DR.WILSON@FRACTO.COM', 'dr.wilson@fracto.com', 'DR.WILSON@FRACTO.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp8', 'ConcurrencyStamp8', 'Dr. Robert', 'Wilson', 'Metropolis', '222 Urology Clinic', '+1-555-0107', GETUTCDATE(), 1),
('doctor-008', 'dr.anderson@fracto.com', 'DR.ANDERSON@FRACTO.COM', 'dr.anderson@fracto.com', 'DR.ANDERSON@FRACTO.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp9', 'ConcurrencyStamp9', 'Dr. Lisa', 'Anderson', 'Metropolis', '333 Imaging Center', '+1-555-0108', GETUTCDATE(), 1),
('doctor-009', 'dr.martinez@fracto.com', 'DR.MARTINEZ@FRACTO.COM', 'dr.martinez@fracto.com', 'DR.MARTINEZ@FRACTO.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp10', 'ConcurrencyStamp10', 'Dr. Carlos', 'Martinez', 'Metropolis', '444 Anesthesia Center', '+1-555-0109', GETUTCDATE(), 1),
('doctor-010', 'dr.thompson@fracto.com', 'DR.THOMPSON@FRACTO.COM', 'dr.thompson@fracto.com', 'DR.THOMPSON@FRACTO.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp11', 'ConcurrencyStamp11', 'Dr. Amanda', 'Thompson', 'Metropolis', '555 Emergency Center', '+1-555-0110', GETUTCDATE(), 1);
GO

-- Insert Patient Users
INSERT INTO Users (Id, UserName, NormalizedUserName, Email, NormalizedEmail, EmailConfirmed, PasswordHash, SecurityStamp, ConcurrencyStamp, FirstName, LastName, City, Address, PhoneNumber, DateOfBirth, CreatedAt, IsActive) VALUES
('patient-001', 'alice.johnson@email.com', 'ALICE.JOHNSON@EMAIL.COM', 'alice.johnson@email.com', 'ALICE.JOHNSON@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp12', 'ConcurrencyStamp12', 'Alice', 'Johnson', 'Metropolis', '111 Patient Street', '+1-555-0201', '1985-03-15', GETUTCDATE(), 1),
('patient-002', 'bob.smith@email.com', 'BOB.SMITH@EMAIL.COM', 'bob.smith@email.com', 'BOB.SMITH@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp13', 'ConcurrencyStamp13', 'Bob', 'Smith', 'Metropolis', '222 Health Lane', '+1-555-0202', '1990-07-22', GETUTCDATE(), 1),
('patient-003', 'carol.wilson@email.com', 'CAROL.WILSON@EMAIL.COM', 'carol.wilson@email.com', 'CAROL.WILSON@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp14', 'ConcurrencyStamp14', 'Carol', 'Wilson', 'Metropolis', '333 Care Road', '+1-555-0203', '1988-11-08', GETUTCDATE(), 1),
('patient-004', 'david.garcia@email.com', 'DAVID.GARCIA@EMAIL.COM', 'david.garcia@email.com', 'DAVID.GARCIA@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp15', 'ConcurrencyStamp15', 'David', 'Garcia', 'Metropolis', '444 Wellness Way', '+1-555-0204', '1992-01-30', GETUTCDATE(), 1),
('patient-005', 'eve.martinez@email.com', 'EVE.MARTINEZ@EMAIL.COM', 'eve.martinez@email.com', 'EVE.MARTINEZ@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp16', 'ConcurrencyStamp16', 'Eve', 'Martinez', 'Metropolis', '555 Medical Path', '+1-555-0205', '1987-09-14', GETUTCDATE(), 1),
('patient-006', 'frank.miller@email.com', 'FRANK.MILLER@EMAIL.COM', 'frank.miller@email.com', 'FRANK.MILLER@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp17', 'ConcurrencyStamp17', 'Frank', 'Miller', 'Metropolis', '666 Health Street', '+1-555-0206', '1983-05-20', GETUTCDATE(), 1),
('patient-007', 'grace.lee@email.com', 'GRACE.LEE@EMAIL.COM', 'grace.lee@email.com', 'GRACE.LEE@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp18', 'ConcurrencyStamp18', 'Grace', 'Lee', 'Metropolis', '777 Care Avenue', '+1-555-0207', '1991-04-12', GETUTCDATE(), 1),
('patient-008', 'henry.chen@email.com', 'HENRY.CHEN@EMAIL.COM', 'henry.chen@email.com', 'HENRY.CHEN@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp19', 'ConcurrencyStamp19', 'Henry', 'Chen', 'Metropolis', '888 Health Street', '+1-555-0208', '1989-08-25', GETUTCDATE(), 1),
('patient-009', 'iris.patel@email.com', 'IRIS.PATEL@EMAIL.COM', 'iris.patel@email.com', 'IRIS.PATEL@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp20', 'ConcurrencyStamp20', 'Iris', 'Patel', 'Metropolis', '999 Medical Lane', '+1-555-0209', '1993-12-03', GETUTCDATE(), 1),
('patient-010', 'jack.white@email.com', 'JACK.WHITE@EMAIL.COM', 'jack.white@email.com', 'JACK.WHITE@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp21', 'ConcurrencyStamp21', 'Jack', 'White', 'Metropolis', '101 Wellness Drive', '+1-555-0210', '1986-06-18', GETUTCDATE(), 1);
GO

-- Insert Doctors
INSERT INTO Doctors (Id, LicenseNumber, Biography, Hospital, Clinic, ConsultationFee, ExperienceYears, IsAvailable, StartTime, EndTime, SpecializationId) VALUES
('doctor-001', 'LIC-CARD-001', 'Experienced cardiologist with 15 years of practice in heart surgery and treatment.', 'Metropolis General Hospital', 'Heart Care Clinic', 500.00, 15, 1, '09:00:00', '17:00:00', 1),
('doctor-002', 'LIC-DERM-002', 'Specialized in dermatology with expertise in skin cancer treatment and cosmetic procedures.', 'Metropolis Medical Center', 'Skin Health Clinic', 400.00, 12, 1, '08:00:00', '16:00:00', 2),
('doctor-003', 'LIC-NEURO-003', 'Neurologist specializing in brain disorders and spinal cord injuries.', 'Metropolis General Hospital', 'Neuro Care Center', 600.00, 18, 1, '10:00:00', '18:00:00', 3),
('doctor-004', 'LIC-ORTHO-004', 'Orthopedic surgeon with expertise in joint replacement and sports medicine.', 'Metropolis Sports Medicine', 'Bone & Joint Clinic', 550.00, 20, 1, '07:00:00', '15:00:00', 4),
('doctor-005', 'LIC-PED-005', 'Pediatrician with 10 years of experience in child health and development.', 'Metropolis Children''s Hospital', 'Kids Care Clinic', 350.00, 10, 1, '09:00:00', '17:00:00', 5),
('doctor-006', 'LIC-ONCO-006', 'Oncologist specializing in breast cancer treatment and research.', 'Metropolis Cancer Center', 'Cancer Care Clinic', 700.00, 14, 1, '08:00:00', '16:00:00', 11),
('doctor-007', 'LIC-URO-007', 'Urologist with expertise in kidney stones and prostate treatment.', 'Metropolis Urology Center', 'Urology Clinic', 450.00, 13, 1, '09:00:00', '17:00:00', 12),
('doctor-008', 'LIC-RAD-008', 'Radiologist specializing in MRI and CT scan interpretation.', 'Metropolis Imaging Center', 'Radiology Clinic', 650.00, 11, 1, '08:00:00', '16:00:00', 13),
('doctor-009', 'LIC-ANES-009', 'Anesthesiologist with expertise in pain management and surgical anesthesia.', 'Metropolis Surgery Center', 'Anesthesia Clinic', 500.00, 16, 1, '07:00:00', '15:00:00', 14),
('doctor-010', 'LIC-EMER-010', 'Emergency medicine physician with trauma and critical care experience.', 'Metropolis Emergency Center', 'Emergency Clinic', 400.00, 9, 1, '12:00:00', '20:00:00', 15);
GO

-- Insert User Roles
INSERT INTO AspNetUserRoles (UserId, RoleId) VALUES
-- Admin role
('admin-001', 'role-admin-001'),
-- Doctor roles
('doctor-001', 'role-doctor-001'),
('doctor-002', 'role-doctor-001'),
('doctor-003', 'role-doctor-001'),
('doctor-004', 'role-doctor-001'),
('doctor-005', 'role-doctor-001'),
('doctor-006', 'role-doctor-001'),
('doctor-007', 'role-doctor-001'),
('doctor-008', 'role-doctor-001'),
('doctor-009', 'role-doctor-001'),
('doctor-010', 'role-doctor-001'),
-- Patient roles
('patient-001', 'role-user-001'),
('patient-002', 'role-user-001'),
('patient-003', 'role-user-001'),
('patient-004', 'role-user-001'),
('patient-005', 'role-user-001'),
('patient-006', 'role-user-001'),
('patient-007', 'role-user-001'),
('patient-008', 'role-user-001'),
('patient-009', 'role-user-001'),
('patient-010', 'role-user-001');
GO

-- Insert Time Slots for next 7 days
INSERT INTO TimeSlots (DoctorId, Date, StartTime, EndTime, IsAvailable, IsBooked, CreatedAt) VALUES
-- Doctor 1 (Cardiology) - Next 7 days
('doctor-001', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '09:00:00', '10:00:00', 1, 0, GETUTCDATE()),
('doctor-001', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '10:00:00', '11:00:00', 1, 0, GETUTCDATE()),
('doctor-001', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '11:00:00', '12:00:00', 1, 0, GETUTCDATE()),
('doctor-001', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '09:00:00', '10:00:00', 1, 0, GETUTCDATE()),
('doctor-001', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '10:00:00', '11:00:00', 1, 0, GETUTCDATE()),
('doctor-001', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '11:00:00', '12:00:00', 1, 0, GETUTCDATE()),

-- Doctor 2 (Dermatology) - Next 7 days
('doctor-002', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '08:00:00', '09:00:00', 1, 0, GETUTCDATE()),
('doctor-002', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '09:00:00', '10:00:00', 1, 0, GETUTCDATE()),
('doctor-002', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '10:00:00', '11:00:00', 1, 0, GETUTCDATE()),
('doctor-002', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '08:00:00', '09:00:00', 1, 0, GETUTCDATE()),
('doctor-002', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '09:00:00', '10:00:00', 1, 0, GETUTCDATE()),
('doctor-002', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '10:00:00', '11:00:00', 1, 0, GETUTCDATE()),

-- Doctor 3 (Neurology) - Next 7 days
('doctor-003', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '10:00:00', '11:00:00', 1, 0, GETUTCDATE()),
('doctor-003', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '11:00:00', '12:00:00', 1, 0, GETUTCDATE()),
('doctor-003', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '12:00:00', '13:00:00', 1, 0, GETUTCDATE()),
('doctor-003', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '10:00:00', '11:00:00', 1, 0, GETUTCDATE()),
('doctor-003', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '11:00:00', '12:00:00', 1, 0, GETUTCDATE()),
('doctor-003', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '12:00:00', '13:00:00', 1, 0, GETUTCDATE()),

-- Doctor 4 (Orthopedics) - Next 7 days
('doctor-004', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '07:00:00', '08:00:00', 1, 0, GETUTCDATE()),
('doctor-004', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '08:00:00', '09:00:00', 1, 0, GETUTCDATE()),
('doctor-004', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '09:00:00', '10:00:00', 1, 0, GETUTCDATE()),
('doctor-004', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '07:00:00', '08:00:00', 1, 0, GETUTCDATE()),
('doctor-004', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '08:00:00', '09:00:00', 1, 0, GETUTCDATE()),
('doctor-004', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '09:00:00', '10:00:00', 1, 0, GETUTCDATE()),

-- Doctor 5 (Pediatrics) - Next 7 days
('doctor-005', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '09:00:00', '10:00:00', 1, 0, GETUTCDATE()),
('doctor-005', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '10:00:00', '11:00:00', 1, 0, GETUTCDATE()),
('doctor-005', DATEADD(DAY, 0, CAST(GETDATE() AS DATE)), '11:00:00', '12:00:00', 1, 0, GETUTCDATE()),
('doctor-005', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '09:00:00', '10:00:00', 1, 0, GETUTCDATE()),
('doctor-005', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '10:00:00', '11:00:00', 1, 0, GETUTCDATE()),
('doctor-005', DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '11:00:00', '12:00:00', 1, 0, GETUTCDATE());
GO

-- Insert Sample Appointments
INSERT INTO Appointments (PatientId, DoctorId, TimeSlotId, AppointmentDate, AppointmentTime, Symptoms, Notes, Status, CreatedAt) VALUES
('patient-001', 'doctor-001', 1, DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '09:00:00', 'Chest pain and shortness of breath', 'Patient experiencing mild chest discomfort', 1, GETUTCDATE()),
('patient-002', 'doctor-002', 7, DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '08:00:00', 'Skin rash on arms and legs', 'Red, itchy patches appeared 3 days ago', 0, GETUTCDATE()),
('patient-003', 'doctor-003', 13, DATEADD(DAY, 2, CAST(GETDATE() AS DATE)), '10:00:00', 'Frequent headaches and dizziness', 'Headaches occur daily, worse in the morning', 1, GETUTCDATE()),
('patient-004', 'doctor-004', 19, DATEADD(DAY, 2, CAST(GETDATE() AS DATE)), '07:00:00', 'Knee pain after running', 'Pain started after marathon training', 0, GETUTCDATE()),
('patient-005', 'doctor-005', 25, DATEADD(DAY, 3, CAST(GETDATE() AS DATE)), '09:00:00', 'Child has fever and cough', '3-year-old with persistent cough for 5 days', 1, GETUTCDATE());
GO

-- Insert Sample Ratings
INSERT INTO Ratings (PatientId, DoctorId, AppointmentId, RatingValue, Review, CreatedAt) VALUES
('patient-001', 'doctor-001', 1, 5, 'Excellent care and very professional. Highly recommended!', GETUTCDATE()),
('patient-002', 'doctor-002', 2, 4, 'Good treatment, doctor was very thorough in examination.', GETUTCDATE()),
('patient-003', 'doctor-003', 3, 5, 'Outstanding neurologist, very knowledgeable and caring.', GETUTCDATE()),
('patient-004', 'doctor-004', 4, 4, 'Great orthopedic care, helped with my knee pain significantly.', GETUTCDATE()),
('patient-005', 'doctor-005', 5, 5, 'Wonderful with children, my kid felt comfortable during the visit.', GETUTCDATE());
GO

-- Update some time slots as booked
UPDATE TimeSlots SET IsBooked = 1 WHERE Id IN (1, 7, 13, 19, 25);
GO

PRINT '✓ All initial data inserted successfully';
PRINT '';

-- =============================================
-- FINAL SUMMARY
-- =============================================

PRINT '=============================================';
PRINT 'BRAND NEW DATABASE CREATED SUCCESSFULLY!';
PRINT 'Database: FractoAppointmentSystem';
PRINT '=============================================';
PRINT '';

DECLARE @TotalSpecializations INT = (SELECT COUNT(*) FROM Specializations);
DECLARE @TotalUsers INT = (SELECT COUNT(*) FROM Users WHERE IsActive = 1);
DECLARE @TotalDoctors INT = (SELECT COUNT(*) FROM Doctors);
DECLARE @TotalPatients INT = (SELECT COUNT(*) FROM Users WHERE Id LIKE 'patient-%' AND IsActive = 1);
DECLARE @TotalTimeSlots INT = (SELECT COUNT(*) FROM TimeSlots);
DECLARE @TotalAppointments INT = (SELECT COUNT(*) FROM Appointments);
DECLARE @TotalRatings INT = (SELECT COUNT(*) FROM Ratings);
DECLARE @TotalRoles INT = (SELECT COUNT(*) FROM AspNetUserRoles);

PRINT 'Database Statistics:';
PRINT '  - Specializations: ' + CAST(@TotalSpecializations AS NVARCHAR(10));
PRINT '  - Active Users: ' + CAST(@TotalUsers AS NVARCHAR(10));
PRINT '  - Doctors: ' + CAST(@TotalDoctors AS NVARCHAR(10));
PRINT '  - Patients: ' + CAST(@TotalPatients AS NVARCHAR(10));
PRINT '  - Time Slots: ' + CAST(@TotalTimeSlots AS NVARCHAR(10));
PRINT '  - Appointments: ' + CAST(@TotalAppointments AS NVARCHAR(10));
PRINT '  - Ratings: ' + CAST(@TotalRatings AS NVARCHAR(10));
PRINT '  - Role Assignments: ' + CAST(@TotalRoles AS NVARCHAR(10));
PRINT '';

PRINT 'Role Distribution:';
PRINT '  - Administrators: ' + CAST((SELECT COUNT(*) FROM AspNetUserRoles ur INNER JOIN AspNetRoles r ON ur.RoleId = r.Id WHERE r.Name = 'Admin') AS NVARCHAR(10));
PRINT '  - Doctors: ' + CAST((SELECT COUNT(*) FROM AspNetUserRoles ur INNER JOIN AspNetRoles r ON ur.RoleId = r.Id WHERE r.Name = 'Doctor') AS NVARCHAR(10));
PRINT '  - Patients: ' + CAST((SELECT COUNT(*) FROM AspNetUserRoles ur INNER JOIN AspNetRoles r ON ur.RoleId = r.Id WHERE r.Name = 'User') AS NVARCHAR(10));
PRINT '';

PRINT 'Specializations Available:';
SELECT Name FROM Specializations ORDER BY Name;
PRINT '';

PRINT '=============================================';
PRINT 'DATABASE IS READY FOR CRUD OPERATIONS!';
PRINT '=============================================';
PRINT '';
PRINT 'The brand new FractoAppointmentSystem database has been created with:';
PRINT '✓ Complete table structure';
PRINT '✓ 15 medical specializations';
PRINT '✓ 1 administrator user';
PRINT '✓ 10 doctor users across all specializations';
PRINT '✓ 10 patient users';
PRINT '✓ Proper role assignments for all users';
PRINT '✓ Sample time slots and appointments';
PRINT '✓ Patient ratings and reviews';
PRINT '';
PRINT 'Ready for API testing and CRUD operations!';
GO


