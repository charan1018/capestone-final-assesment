-- =============================================
-- SIMPLE CRUD OPERATIONS DEMONSTRATION
-- Database: FractoAppointmentSystem
-- =============================================

USE FractoAppointmentSystem;
GO

PRINT '=============================================';
PRINT 'SIMPLE CRUD OPERATIONS DEMONSTRATION';
PRINT 'Database: FractoAppointmentSystem';
PRINT '=============================================';
PRINT '';

-- =============================================
-- READ OPERATIONS (SELECT)
-- =============================================

PRINT '1. READ OPERATIONS - Viewing Data';
PRINT '====================================';
PRINT '';

-- View all specializations
PRINT 'All Specializations:';
SELECT Id, Name, Description FROM Specializations ORDER BY Name;
PRINT '';

-- View all doctors
PRINT 'All Doctors:';
SELECT 
    d.Id,
    u.FirstName,
    u.LastName,
    u.Email,
    s.Name AS Specialization,
    d.ConsultationFee,
    d.ExperienceYears
FROM Doctors d
INNER JOIN Users u ON d.Id = u.Id
INNER JOIN Specializations s ON d.SpecializationId = s.Id
ORDER BY u.LastName;
PRINT '';

-- View all patients
PRINT 'All Patients:';
SELECT 
    Id,
    FirstName,
    LastName,
    Email,
    PhoneNumber,
    City
FROM Users 
WHERE Id LIKE 'patient-%'
ORDER BY LastName;
PRINT '';

-- View all appointments
PRINT 'All Appointments:';
SELECT 
    a.Id,
    a.PatientId,
    a.DoctorId,
    a.AppointmentDate,
    a.AppointmentTime,
    a.Symptoms,
    a.Status
FROM Appointments a
ORDER BY a.AppointmentDate;
PRINT '';

-- View all ratings
PRINT 'All Ratings:';
SELECT 
    r.Id,
    r.PatientId,
    r.DoctorId,
    r.RatingValue,
    r.Review
FROM Ratings r
ORDER BY r.RatingValue DESC;
PRINT '';

-- =============================================
-- CREATE OPERATIONS (INSERT)
-- =============================================

PRINT '2. CREATE OPERATIONS - Adding New Data';
PRINT '========================================';
PRINT '';

-- Add new patient
INSERT INTO Users (Id, UserName, NormalizedUserName, Email, NormalizedEmail, EmailConfirmed, PasswordHash, SecurityStamp, ConcurrencyStamp, FirstName, LastName, City, Address, PhoneNumber, DateOfBirth, CreatedAt, IsActive) VALUES
('patient-011', 'test.patient@email.com', 'TEST.PATIENT@EMAIL.COM', 'test.patient@email.com', 'TEST.PATIENT@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp22', 'ConcurrencyStamp22', 'Test', 'Patient', 'Metropolis', '999 Test Street', '+1-555-0211', '1990-01-01', GETUTCDATE(), 1);

INSERT INTO AspNetUserRoles (UserId, RoleId) VALUES ('patient-011', 'role-user-001');
PRINT '✓ Added new patient: Test Patient';
PRINT '';

-- Add new appointment
INSERT INTO Appointments (PatientId, DoctorId, AppointmentDate, AppointmentTime, Symptoms, Notes, Status, CreatedAt) VALUES
('patient-011', 'doctor-001', DATEADD(DAY, 3, CAST(GETDATE() AS DATE)), '10:00:00', 'Test appointment', 'Testing CRUD operations', 0, GETUTCDATE());
PRINT '✓ Added new appointment for Test Patient';
PRINT '';

-- Add new rating
INSERT INTO Ratings (PatientId, DoctorId, RatingValue, Review, CreatedAt) VALUES
('patient-001', 'doctor-002', 4, 'Test rating for CRUD demo', GETUTCDATE());
PRINT '✓ Added new rating';
PRINT '';

-- =============================================
-- UPDATE OPERATIONS (UPDATE)
-- =============================================

PRINT '3. UPDATE OPERATIONS - Modifying Data';
PRINT '=====================================';
PRINT '';

-- Update patient information
UPDATE Users 
SET Address = 'Updated Test Address', 
    PhoneNumber = '+1-555-9999',
    UpdatedAt = GETUTCDATE()
WHERE Id = 'patient-011';
PRINT '✓ Updated patient information';
PRINT '';

-- Update appointment status
UPDATE Appointments 
SET Status = 1, 
    UpdatedAt = GETUTCDATE()
WHERE PatientId = 'patient-011';
PRINT '✓ Updated appointment status to Confirmed';
PRINT '';

-- Update doctor availability
UPDATE Doctors 
SET IsAvailable = 0
WHERE Id = 'doctor-001';
PRINT '✓ Updated doctor availability';
PRINT '';

-- =============================================
-- DELETE OPERATIONS (DELETE)
-- =============================================

PRINT '4. DELETE OPERATIONS - Removing Data';
PRINT '======================================';
PRINT '';

-- Delete a rating
DELETE FROM Ratings WHERE PatientId = 'patient-001' AND DoctorId = 'doctor-002' AND Review = 'Test rating for CRUD demo';
PRINT '✓ Deleted test rating';
PRINT '';

-- Delete an appointment
DELETE FROM Appointments WHERE PatientId = 'patient-011';
PRINT '✓ Deleted test appointment';
PRINT '';

-- Delete a patient
DELETE FROM AspNetUserRoles WHERE UserId = 'patient-011';
DELETE FROM Users WHERE Id = 'patient-011';
PRINT '✓ Deleted test patient';
PRINT '';

-- =============================================
-- ANALYTICS AND REPORTING
-- =============================================

PRINT '5. ANALYTICS AND REPORTING';
PRINT '===========================';
PRINT '';

-- Count by status
PRINT 'Appointment Count by Status:';
SELECT 
    Status,
    COUNT(*) AS Count
FROM Appointments
GROUP BY Status
ORDER BY Status;
PRINT '';

-- Average rating by doctor
PRINT 'Average Rating by Doctor:';
SELECT 
    DoctorId,
    AVG(CAST(RatingValue AS FLOAT)) AS AverageRating,
    COUNT(*) AS TotalRatings
FROM Ratings
GROUP BY DoctorId
ORDER BY AverageRating DESC;
PRINT '';

-- Specialization count
PRINT 'Doctor Count by Specialization:';
SELECT 
    s.Name AS Specialization,
    COUNT(d.Id) AS DoctorCount
FROM Specializations s
LEFT JOIN Doctors d ON s.Id = d.SpecializationId
GROUP BY s.Id, s.Name
ORDER BY DoctorCount DESC;
PRINT '';

-- =============================================
-- FINAL SUMMARY
-- =============================================

PRINT '=============================================';
PRINT 'CRUD OPERATIONS DEMONSTRATION COMPLETED!';
PRINT '=============================================';
PRINT '';

DECLARE @FinalSpecializations INT = (SELECT COUNT(*) FROM Specializations);
DECLARE @FinalUsers INT = (SELECT COUNT(*) FROM Users WHERE IsActive = 1);
DECLARE @FinalDoctors INT = (SELECT COUNT(*) FROM Doctors);
DECLARE @FinalPatients INT = (SELECT COUNT(*) FROM Users WHERE Id LIKE 'patient-%' AND IsActive = 1);
DECLARE @FinalAppointments INT = (SELECT COUNT(*) FROM Appointments);
DECLARE @FinalRatings INT = (SELECT COUNT(*) FROM Ratings);
DECLARE @FinalRoles INT = (SELECT COUNT(*) FROM AspNetUserRoles);

PRINT 'Final Database Statistics:';
PRINT '  - Specializations: ' + CAST(@FinalSpecializations AS NVARCHAR(10));
PRINT '  - Active Users: ' + CAST(@FinalUsers AS NVARCHAR(10));
PRINT '  - Doctors: ' + CAST(@FinalDoctors AS NVARCHAR(10));
PRINT '  - Patients: ' + CAST(@FinalPatients AS NVARCHAR(10));
PRINT '  - Appointments: ' + CAST(@FinalAppointments AS NVARCHAR(10));
PRINT '  - Ratings: ' + CAST(@FinalRatings AS NVARCHAR(10));
PRINT '  - Role Assignments: ' + CAST(@FinalRoles AS NVARCHAR(10));
PRINT '';

PRINT 'CRUD Operations Demonstrated:';
PRINT '✓ CREATE: Added new patient, appointment, and rating';
PRINT '✓ READ: Viewed all data with joins and filtering';
PRINT '✓ UPDATE: Modified patient info, appointment status, doctor availability';
PRINT '✓ DELETE: Removed rating, appointment, and patient';
PRINT '✓ ANALYTICS: Generated reports on appointments, ratings, and trends';
PRINT '';

PRINT '=============================================';
PRINT 'DATABASE IS READY FOR API TESTING!';
PRINT '=============================================';
PRINT '';
PRINT 'The FractoAppointmentSystem database is now fully operational with:';
PRINT '• Complete CRUD operations demonstrated';
PRINT '• Proper role-based access control';
PRINT '• Sample data for testing all endpoints';
PRINT '• Analytics and reporting capabilities';
PRINT '';
PRINT 'Ready for frontend-backend integration!';
GO


