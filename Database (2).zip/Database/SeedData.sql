USE FractoAppointmentDB;
GO

-- Seed Specializations (if not already seeded by EF)
IF NOT EXISTS (SELECT * FROM Specializations WHERE Id = 1)
BEGIN
    INSERT INTO Specializations (Id, Name, Description, IsActive, CreatedAt) VALUES
    (1, 'Cardiology', 'Heart and cardiovascular system', 1, GETUTCDATE()),
    (2, 'Dermatology', 'Skin, hair, and nails', 1, GETUTCDATE()),
    (3, 'Neurology', 'Nervous system and brain', 1, GETUTCDATE()),
    (4, 'Orthopedics', 'Bones, joints, and muscles', 1, GETUTCDATE()),
    (5, 'Pediatrics', 'Children''s health', 1, GETUTCDATE()),
    (6, 'Psychiatry', 'Mental health', 1, GETUTCDATE()),
    (7, 'General Medicine', 'General health and wellness', 1, GETUTCDATE());
END

-- Seed Sample Doctors (if needed)
-- Note: These will be created through the registration process in the application
-- This is just a reference for testing

PRINT 'Database seeded with initial data!';
PRINT 'Specializations have been added.';
PRINT 'Doctors and users should be created through the application registration process.';
GO








