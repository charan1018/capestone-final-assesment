-- =============================================
-- COMPLETE CRUD OPERATIONS DEMONSTRATION
-- Database: FractoAppointmentSystem
-- =============================================

USE FractoAppointmentSystem;
GO

PRINT '=============================================';
PRINT 'COMPLETE CRUD OPERATIONS DEMONSTRATION';
PRINT 'Database: FractoAppointmentSystem';
PRINT '=============================================';
PRINT '';

-- =============================================
-- READ OPERATIONS (SELECT)
-- =============================================

PRINT '1. READ OPERATIONS - Viewing Data';
PRINT '====================================';
PRINT '';

-- View all specializations
PRINT 'All Specializations:';
SELECT Id, Name, Description, IsActive FROM Specializations ORDER BY Name;
PRINT '';

-- View all doctors with their specializations
PRINT 'All Doctors with Specializations:';
SELECT 
    d.Id,
    u.FirstName + ' ' + u.LastName AS DoctorName,
    u.Email,
    s.Name AS Specialization,
    d.ConsultationFee,
    d.ExperienceYears,
    d.Hospital,
    d.IsAvailable
FROM Doctors d
INNER JOIN Users u ON d.Id = u.Id
INNER JOIN Specializations s ON d.SpecializationId = s.Id
ORDER BY s.Name, u.LastName;
PRINT '';

-- View all patients
PRINT 'All Patients:';
SELECT 
    Id,
    FirstName + ' ' + LastName AS PatientName,
    Email,
    PhoneNumber,
    City,
    DateOfBirth,
    IsActive
FROM Users 
WHERE Id LIKE 'patient-%'
ORDER BY LastName, FirstName;
PRINT '';

-- View all appointments
PRINT 'All Appointments:';
SELECT 
    a.Id,
    p.FirstName + ' ' + p.LastName AS PatientName,
    d.FirstName + ' ' + d.LastName AS DoctorName,
    s.Name AS Specialization,
    a.AppointmentDate,
    a.AppointmentTime,
    a.Symptoms,
    a.Status,
    CASE a.Status
        WHEN 0 THEN 'Pending'
        WHEN 1 THEN 'Confirmed'
        WHEN 2 THEN 'Completed'
        WHEN 3 THEN 'Cancelled'
        ELSE 'Unknown'
    END AS StatusText
FROM Appointments a
INNER JOIN Users p ON a.PatientId = p.Id
INNER JOIN Doctors doc ON a.DoctorId = doc.Id
INNER JOIN Users d ON doc.Id = d.Id
INNER JOIN Specializations s ON doc.SpecializationId = s.Id
ORDER BY a.AppointmentDate, a.AppointmentTime;
PRINT '';

-- View all ratings
PRINT 'All Ratings:';
SELECT 
    r.Id,
    p.FirstName + ' ' + p.LastName AS PatientName,
    d.FirstName + ' ' + d.LastName AS DoctorName,
    r.RatingValue,
    r.Review,
    r.CreatedAt
FROM Ratings r
INNER JOIN Users p ON r.PatientId = p.Id
INNER JOIN Doctors doc ON r.DoctorId = doc.Id
INNER JOIN Users d ON doc.Id = d.Id
ORDER BY r.RatingValue DESC, r.CreatedAt DESC;
PRINT '';

-- =============================================
-- CREATE OPERATIONS (INSERT)
-- =============================================

PRINT '2. CREATE OPERATIONS - Adding New Data';
PRINT '========================================';
PRINT '';

-- Add new patient
INSERT INTO Users (Id, UserName, NormalizedUserName, Email, NormalizedEmail, EmailConfirmed, PasswordHash, SecurityStamp, ConcurrencyStamp, FirstName, LastName, City, Address, PhoneNumber, DateOfBirth, CreatedAt, IsActive) VALUES
('patient-011', 'new.patient@email.com', 'NEW.PATIENT@EMAIL.COM', 'new.patient@email.com', 'NEW.PATIENT@EMAIL.COM', 1, 'AQAAAAEAACcQAAAAEHashPasswordHere', 'SecurityStamp22', 'ConcurrencyStamp22', 'New', 'Patient', 'Metropolis', '999 New Street', '+1-555-0211', '1990-01-01', GETUTCDATE(), 1);

INSERT INTO AspNetUserRoles (UserId, RoleId) VALUES ('patient-011', 'role-user-001');
PRINT '✓ Added new patient: New Patient';
PRINT '';

-- Add new appointment
INSERT INTO Appointments (PatientId, DoctorId, AppointmentDate, AppointmentTime, Symptoms, Notes, Status, CreatedAt) VALUES
('patient-011', 'doctor-001', DATEADD(DAY, 3, CAST(GETDATE() AS DATE)), '10:00:00', 'Regular checkup', 'Annual health checkup', 0, GETUTCDATE());
PRINT '✓ Added new appointment for New Patient';
PRINT '';

-- Add new rating
INSERT INTO Ratings (PatientId, DoctorId, RatingValue, Review, CreatedAt) VALUES
('patient-001', 'doctor-002', 4, 'Good service, professional approach', GETUTCDATE());
PRINT '✓ Added new rating';
PRINT '';

-- =============================================
-- UPDATE OPERATIONS (UPDATE)
-- =============================================

PRINT '3. UPDATE OPERATIONS - Modifying Data';
PRINT '=====================================';
PRINT '';

-- Update patient information
UPDATE Users 
SET Address = 'Updated Address Street', 
    PhoneNumber = '+1-555-9999',
    UpdatedAt = GETUTCDATE()
WHERE Id = 'patient-011';
PRINT '✓ Updated patient information';
PRINT '';

-- Update appointment status
UPDATE Appointments 
SET Status = 1, 
    UpdatedAt = GETUTCDATE()
WHERE PatientId = 'patient-011' AND DoctorId = 'doctor-001';
PRINT '✓ Updated appointment status to Confirmed';
PRINT '';

-- Update doctor availability
UPDATE Doctors 
SET IsAvailable = 0
WHERE Id = 'doctor-001';
PRINT '✓ Updated doctor availability';
PRINT '';

-- =============================================
-- DELETE OPERATIONS (DELETE)
-- =============================================

PRINT '4. DELETE OPERATIONS - Removing Data';
PRINT '======================================';
PRINT '';

-- Delete a rating
DELETE FROM Ratings WHERE PatientId = 'patient-001' AND DoctorId = 'doctor-002';
PRINT '✓ Deleted rating';
PRINT '';

-- Delete an appointment
DELETE FROM Appointments WHERE PatientId = 'patient-011';
PRINT '✓ Deleted appointment';
PRINT '';

-- Delete a patient
DELETE FROM AspNetUserRoles WHERE UserId = 'patient-011';
DELETE FROM Users WHERE Id = 'patient-011';
PRINT '✓ Deleted patient';
PRINT '';

-- =============================================
-- ANALYTICS AND REPORTING
-- =============================================

PRINT '5. ANALYTICS AND REPORTING';
PRINT '===========================';
PRINT '';

-- Appointment statistics by status
PRINT 'Appointment Statistics by Status:';
SELECT 
    CASE Status
        WHEN 0 THEN 'Pending'
        WHEN 1 THEN 'Confirmed'
        WHEN 2 THEN 'Completed'
        WHEN 3 THEN 'Cancelled'
        ELSE 'Unknown'
    END AS StatusText,
    COUNT(*) AS Count,
    CAST(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM Appointments) AS DECIMAL(5,2)) AS Percentage
FROM Appointments
GROUP BY Status
ORDER BY Status;
PRINT '';

-- Top rated doctors
PRINT 'Top Rated Doctors:';
SELECT 
    d.FirstName + ' ' + d.LastName AS DoctorName,
    s.Name AS Specialization,
    AVG(CAST(r.RatingValue AS FLOAT)) AS AverageRating,
    COUNT(r.Id) AS TotalRatings
FROM Doctors d
INNER JOIN Users u ON d.Id = u.Id
INNER JOIN Specializations s ON d.SpecializationId = s.Id
LEFT JOIN Ratings r ON d.Id = r.DoctorId
GROUP BY d.Id, u.FirstName, u.LastName, s.Name
HAVING COUNT(r.Id) > 0
ORDER BY AverageRating DESC, TotalRatings DESC;
PRINT '';

-- Specialization popularity
PRINT 'Specialization Popularity:';
SELECT 
    s.Name AS Specialization,
    COUNT(DISTINCT d.Id) AS DoctorCount,
    COUNT(a.Id) AS AppointmentCount,
    AVG(d.ConsultationFee) AS AverageFee
FROM Specializations s
LEFT JOIN Doctors d ON s.Id = d.SpecializationId
LEFT JOIN Appointments a ON d.Id = a.DoctorId
GROUP BY s.Id, s.Name
ORDER BY AppointmentCount DESC, DoctorCount DESC;
PRINT '';

-- Monthly appointment trends
PRINT 'Monthly Appointment Trends:';
SELECT 
    YEAR(AppointmentDate) AS Year,
    MONTH(AppointmentDate) AS Month,
    COUNT(*) AS AppointmentCount
FROM Appointments
GROUP BY YEAR(AppointmentDate), MONTH(AppointmentDate)
ORDER BY Year DESC, Month DESC;
PRINT '';

-- =============================================
-- FINAL SUMMARY
-- =============================================

PRINT '=============================================';
PRINT 'CRUD OPERATIONS DEMONSTRATION COMPLETED!';
PRINT '=============================================';
PRINT '';

DECLARE @FinalSpecializations INT = (SELECT COUNT(*) FROM Specializations);
DECLARE @FinalUsers INT = (SELECT COUNT(*) FROM Users WHERE IsActive = 1);
DECLARE @FinalDoctors INT = (SELECT COUNT(*) FROM Doctors);
DECLARE @FinalPatients INT = (SELECT COUNT(*) FROM Users WHERE Id LIKE 'patient-%' AND IsActive = 1);
DECLARE @FinalAppointments INT = (SELECT COUNT(*) FROM Appointments);
DECLARE @FinalRatings INT = (SELECT COUNT(*) FROM Ratings);
DECLARE @FinalRoles INT = (SELECT COUNT(*) FROM AspNetUserRoles);

PRINT 'Final Database Statistics:';
PRINT '  - Specializations: ' + CAST(@FinalSpecializations AS NVARCHAR(10));
PRINT '  - Active Users: ' + CAST(@FinalUsers AS NVARCHAR(10));
PRINT '  - Doctors: ' + CAST(@FinalDoctors AS NVARCHAR(10));
PRINT '  - Patients: ' + CAST(@FinalPatients AS NVARCHAR(10));
PRINT '  - Appointments: ' + CAST(@FinalAppointments AS NVARCHAR(10));
PRINT '  - Ratings: ' + CAST(@FinalRatings AS NVARCHAR(10));
PRINT '  - Role Assignments: ' + CAST(@FinalRoles AS NVARCHAR(10));
PRINT '';

PRINT 'CRUD Operations Demonstrated:';
PRINT '✓ CREATE: Added new patient, appointment, and rating';
PRINT '✓ READ: Viewed all data with complex joins and filtering';
PRINT '✓ UPDATE: Modified patient info, appointment status, doctor availability';
PRINT '✓ DELETE: Removed rating, appointment, and patient';
PRINT '✓ ANALYTICS: Generated reports on appointments, ratings, and trends';
PRINT '';

PRINT '=============================================';
PRINT 'DATABASE IS READY FOR API TESTING!';
PRINT '=============================================';
PRINT '';
PRINT 'The FractoAppointmentSystem database is now fully operational with:';
PRINT '• Complete CRUD operations demonstrated';
PRINT '• Proper role-based access control';
PRINT '• Sample data for testing all endpoints';
PRINT '• Analytics and reporting capabilities';
PRINT '';
PRINT 'Ready for frontend-backend integration!';
GO


